vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|25 Feb 2008 07:55:26 -0000
vti_extenderversion:SR|6.0.2.6551
vti_cacheddtm:TX|03 Feb 2004 21:09:02 -0000
vti_filesize:IR|1305
vti_backlinkinfo:VX|
vti_syncwith_194.57.140.253\:21/public_html:TW|03 Feb 2004 21:09:02 -0000
vti_syncofs_194.57.140.253\:21/public_html:TW|17 Jan 2007 09:08:38 -0000
vti_modifiedby:SR|PC-de-robin\\robin
vti_syncofs_www.mim.univ-metz.fr\:21/public_html:TW|25 Feb 2008 07:34:00 -0000
vti_syncwith_www.mim.univ-metz.fr\:21/public_html:TX|03 Feb 2004 21:09:02 -0000
