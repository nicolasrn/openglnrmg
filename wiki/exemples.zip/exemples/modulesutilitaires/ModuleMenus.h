

#ifndef MODULEMENUS
#define MODULEMENUS

void creationMenuBasique(void) ;

#endif
