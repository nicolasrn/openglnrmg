#include "Model.h"
#include "OBJReader.h"
#include "Light.h"
#ifdef WIN32
#include <windows.h>
#endif
#include <GL/gl.h>

Model::Model(void)
{
	vertex = NULL;
	normals = NULL;
	texCoords = NULL;
	faces = NULL;
	nbVertex = 0;
	nbNormals = 0;
	nbTexCoord = 0;
	nbFaces = 0;
}

Model::~Model(void)
{
	delete[] vertex;
	delete[] normals;
	delete[] texCoords;
	delete[] faces;
}

bool Model::load(const std::string & filePath)
{
	// on cr�e un lecteur de .obj
	OBJReader reader(filePath);
	// on charge le model
	if (reader.load())
	{
		// le model est bien charge
		// on alloue le tableau de vertex
		vertex = new Vecteur[reader.getVertex().size()];
		nbVertex = 0;
		// on copie les informations des vertex
		for (std::vector<OBJReader::OBJVector>::iterator it = reader.getVertex().begin(); it != reader.getVertex().end(); ++it)
		{
			vertex[nbVertex].x = (*it).x;
			vertex[nbVertex].y = (*it).y;
			vertex[nbVertex].z = (*it).z;
			nbVertex++;
		}
		// on alloue le tableau de normales
		normals = new Vecteur[reader.getNormal().size()];
		nbNormals = 0;
		// on copie les informations des normales
		for (std::vector<OBJReader::OBJVector>::iterator it = reader.getNormal().begin(); it != reader.getNormal().end(); ++it)
		{
			normals[nbNormals].x = (*it).x;
			normals[nbNormals].y = (*it).y;
			normals[nbNormals].z = (*it).z;
			nbNormals++;
		}
		// on alloue le tableau de coordonn�e de textures
		texCoords = new TexCoord[reader.getTexture().size()];
		nbTexCoord = 0;
		// on copie les informations de coordonn�e de texture
		for (std::vector<OBJReader::OBJtexCoord>::iterator it = reader.getTexture().begin(); it != reader.getTexture().end(); ++it)
		{
			texCoords[nbTexCoord].u = (*it).u;
			texCoords[nbTexCoord].v = (*it).v;
			nbTexCoord++;
		}
		// on alloue le tableau de faces
		faces = new Face[reader.getFace().size()];
		nbFaces = 0;
		// on copie les informations des faces
		for (std::vector<OBJReader::OBJface>::iterator it = reader.getFace().begin(); it != reader.getFace().end(); ++it)
		{
			faces[nbFaces].vertexIndex[0] = (*it).vertex[0];
			faces[nbFaces].vertexIndex[1] = (*it).vertex[1];
			faces[nbFaces].vertexIndex[2] = (*it).vertex[2];
			faces[nbFaces].normalIndex[0] = (*it).normal[0];
			faces[nbFaces].normalIndex[1] = (*it).normal[1];
			faces[nbFaces].normalIndex[2] = (*it).normal[2];
			faces[nbFaces].texCoordIndex[0] = (*it).texture[0];
			faces[nbFaces].texCoordIndex[1] = (*it).texture[1];
			faces[nbFaces].texCoordIndex[2] = (*it).texture[2];
			faces[nbFaces].color[0].set(0,0,0);
			faces[nbFaces].color[1].set(0,0,0);
			faces[nbFaces].color[2].set(0,0,0);
			nbFaces++;
		}
		return true;
	}
	else
	{
		return false;
	}
}

void Model::initLighting(const Color& ambiant)
{
	// on met la couleur de chaque sommet de chaque face a noir
	for (int i = 0; i < nbFaces; i++)
	{
		faces[i].color[0] = ambiant;
		faces[i].color[1] = ambiant;
		faces[i].color[2] = ambiant;
	}
}

void Model::addLight(Light& light)
{
	// pour chaque face
	for (int i = 0; i < nbFaces; i++)
	{
		// pour chaque vertex de la face
		for (int j = 0; j < 3; j++){
			// on calcule la lumiere
			Color c = light.computeLighting(vertex[faces[i].vertexIndex[j]],normals[faces[i].normalIndex[j]]);
			// et on l'addition avec la lumiere precedente
			faces[i].color[j].r += c.r;
			faces[i].color[j].g += c.g;
			faces[i].color[j].b += c.b;
		}
	}
}

void Model::render()
{
	glBegin(GL_TRIANGLES);
	for(int i = 0;i < nbFaces; i++){
		for (int j = 0; j < 3; j++){
			Color &c = faces[i].color[j];
			TexCoord &tc = texCoords[faces[i].texCoordIndex[j]];
			Vecteur &v = vertex[faces[i].vertexIndex[j]];
			glColor3f(c.r,c.g,c.b);
			glTexCoord2f(tc.u,tc.v);
			glVertex3f(v.x,v.y,v.z);
		}
	}
	glEnd();
}


