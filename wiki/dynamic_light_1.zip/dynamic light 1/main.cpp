#include <stdlib.h>
#include <math.h>
#include <GL/glut.h>
#ifdef WIN32
#include <windows.h>
#endif
#include <GL/gl.h>

#include "TGA.h"
#include "Model.h"
#include "Light.h"

// le model sur lequel on va travailler
Model * model = NULL;
// l'identifiant de la texture utilis� par le model
unsigned int textureId;
// la couleur ambiante de l'affichage
Color ambiant;
// la lumiere rouge
Light redLight;
// la lumiere bleu
Light blueLight;
// la lumiere blanche
Light whiteLight;

float angleRotationY = 0;
float cameraHeight = 8;
float whiteAngle = 0;
bool useWhiteLight = true;
/**
 * fonction appel� par GLUT pour dessiner la scene
 */
void draw(void)
{
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	float posX = cos(angleRotationY*(3.141/180))*8;
	float posZ = sin(angleRotationY*(3.141/180))*8;
	gluLookAt (posX,cameraHeight,posZ,0,0,0,0,1,0);

	model->initLighting(ambiant);
	// on ajoute nos lumieres
	model->addLight(redLight);
	model->addLight(blueLight);
	if (useWhiteLight)
	{
		model->addLight(whiteLight);
	}
	// on active la texture
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D,textureId);
	model->render();
	glDisable(GL_TEXTURE_2D);

	// on affiche les lumieres
	glPointSize(5.0f);
	glBegin(GL_POINTS);
		glColor3f(redLight.getColor().r,redLight.getColor().g,redLight.getColor().b);
		glVertex3f(redLight.getPosition().x,redLight.getPosition().y,redLight.getPosition().z);
		glColor3f(blueLight.getColor().r,blueLight.getColor().g,blueLight.getColor().b);
		glVertex3f(blueLight.getPosition().x,blueLight.getPosition().y,blueLight.getPosition().z);
		glColor3f(whiteLight.getColor().r,whiteLight.getColor().g,whiteLight.getColor().b);
		glVertex3f(whiteLight.getPosition().x,whiteLight.getPosition().y,whiteLight.getPosition().z);
	glEnd();
	glPointSize(1.0f);

	glutSwapBuffers();
	glFlush();
}

/**
 * fonction appel� par GLUT � la fin de la fonction de dessin
 */
void idle(void)
{

	// on demande � glut de redessiner la scene
	glutPostRedisplay();
}

/**
 * fonction appel� par GLUT lors de l'appuye sur un bouton de la souris
 * @param boutton : le bouton utilis�. peut etre GLUT_MIDDLE_BUTTON, GLUT_LEFT_BUTTON ou GLUT_RIGHT_BUTTON
 * @param etat : l'etat du boutton. peut etre GLUT_UP ou GLUT_DOWN
 * @param x : la position X du curseur de la souris
 * @param y : la position Y du curseur de la souris
 */
void mouse(int boutton,int etat,int x,int y)
{
}

/**
 * fonction appel� par GLUT lors de l'appuye sur une touche du clavier
 * @param key : la touche (en UNICODE) utilis�e
 * @param x : la position X du curseur de la souris
 * @param y : la position Y du curseur de la souris
 */
void keyboard(unsigned char key,int x,int y)
{
	switch(key)
	{
		case 27:
			delete model;
			glutLeaveGameMode();
			exit(0); // quitte
		break;
		case '4':
			angleRotationY --;
			break;
		case '6':
			angleRotationY ++;
			break;
		case '8':
			cameraHeight++;
			break;
		case '2':
			cameraHeight--;
			break;
		case '7':
			whiteAngle --;
			whiteLight.setPosition(cos(whiteAngle*(3.141/180))*4,1,sin(whiteAngle*(3.141/180))*4);
			break;
		case '9':
			whiteAngle ++;
			whiteLight.setPosition(cos(whiteAngle*(3.141/180))*4,1,sin(whiteAngle*(3.141/180))*4);
			break;
		case ' ':
			useWhiteLight = !useWhiteLight;
			break;
	}
}

/**
 * fonction appel� par GLUT lors du redimentionnement de la fenetre
 * @param width : la largeur de la fenetre
 * @param height : la hauteur de la fenetre
 */
void reshape(int width,int height)
{
	glViewport(0,0,(GLsizei) width,(GLsizei) height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45,width/height,1,1000);
	glMatrixMode(GL_MODELVIEW);
}

/**
 * fonction utilis�e pour initialiser openGL
 */
void initGLState()
{
	glClearColor(0,0,0,0);
	glClearDepth(1010);
	glDepthFunc(GL_LEQUAL);
	glEnable (GL_DEPTH_TEST);
}

/**
 * fonction utilis�e pour initialiser les callback glut
 */
void initCallback()
{
	glutDisplayFunc(draw);
	glutIdleFunc(idle);
	glutMouseFunc(mouse);
	glutKeyboardFunc(keyboard);
	glutReshapeFunc(reshape);
}

/**
 * fonction appel�e pour initialiser les textures utilis�es dans le programme
 */
void initTextures()
{
	glEnable(GL_TEXTURE_2D);
	TGA image;
	if (image.load("rock.tga"))
	{
		glGenTextures (1, &textureId); 
		glBindTexture(GL_TEXTURE_2D, textureId); 
		if (image.getBpp() == 24)
		{
			gluBuild2DMipmaps(GL_TEXTURE_2D, 3, image.getWidth(), image.getHeight(),GL_RGB, GL_UNSIGNED_BYTE, image.getDatas());  
		}
		else
		{
			gluBuild2DMipmaps(GL_TEXTURE_2D, 4, image.getWidth(), image.getHeight(),GL_RGBA, GL_UNSIGNED_BYTE, image.getDatas());  
		}
	}
	else
	{
		fprintf(stderr,"impossible de charger l'image rock.tga");
		exit(0);
	}

}

/**
 * Fonction principal du programme
 */
void main(int argc,char** argv)
{
	glutInit(&argc,argv);

	glutInitDisplayMode(GLUT_RGBA|GLUT_DOUBLE|GLUT_DEPTH);
	glutGameModeString("1024x768:32@85");
	glutEnterGameMode();
	//glutInitWindowSize(1024,768);
	//glutCreateWindow("projet");

	initGLState();
	initTextures();
	initCallback();

	model = new Model();
	ambiant.set(0.2,0.2,0.2);
	if (!model->load("scene.obj")){
		fprintf(stderr,"impossible de charger le fichier scene.obj");
		delete model;
		exit(0);
	}
	redLight.setColor(1,0,0);
	redLight.setPosition(5,5,0);
	redLight.setRadius(15);
	blueLight.setColor(0,0,1);
	blueLight.setPosition(-5,5,0);
	blueLight.setRadius(20);
	whiteLight.setColor(1,1,1);
	whiteLight.setRadius(20);
	whiteLight.setPosition(cos(whiteAngle*(3.141/180))*4,1,sin(whiteAngle*(3.141/180))*4);

	glutMainLoop();
}
