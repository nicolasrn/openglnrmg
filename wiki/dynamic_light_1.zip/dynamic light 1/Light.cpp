#include "Light.h"
#include <math.h>

Light::Light(void)
{
	radius = 100;
	color.set(1,1,1);
	position.x = 0;
	position.y = 0;
	position.z = 0;

}

Light::~Light(void)
{
}

void Light::setRadius(float r)
{
	radius = fabs(r);
}

float Light::getRadius()
{
	return radius;
}

void Light::setColor(float r, float g, float b)
{
	color.set(r,g,b);
}

Color Light::getColor()
{
	return color;
}

void Light::setPosition(float x, float y, float z)
{
	position.x = x;
	position.y = y;
	position.z = z;
}

Vecteur Light::getPosition()
{
	return position;
}

Color Light::computeLighting(const Vecteur & position, const Vecteur & normal)
{
	Vecteur vertexToLight = this->position - position;
	vertexToLight.normalise();
	float attenuation = std::max<float>(0.0f,1.0f - (vertexToLight.getLength() / radius));
	attenuation *= vertexToLight*normal;
	attenuation = std::max<float>(0.0f,attenuation);
	Color ret = this->color;
	ret.r *= attenuation;
	ret.g *= attenuation;
	ret.b *= attenuation;
	return ret;
}
