/* Auteur: Nicolas JANEY            */
/* nicolas.janey@univ-fcomte.fr     */
/* Septembre 2005                   */
/* Gestion des menus                */

#ifndef MODULEMENUS
#define MODULEMENUS

void creationMenuBasique(void) ;

#endif
