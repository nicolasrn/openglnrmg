/*									TPFH R�alit� virtuelle								*
 *											(ESIEA)										*
 ****************************************************************************************/
#include <windows.h>					// En-t�te standart aux prog. Windows
#include <gl\gl.h>						// fonctions OpenGL
#include <gl\glaux.h>					// Librairie AUX
#include <math.h>
#include <stdio.h>
#include "definitions.h"

// declarations devant imp�rativement �tre pr�sentes
GLfloat light0_pos[4]={-50.0f,30.0f,5.0f,1.0f};
GLfloat obj_x=5.0f, obj_y=9.5f, obj_z=21.0f;
GLfloat ambient[] = {0.4f,0.4f,0.4f,1.0f};
GLfloat diffuse[] = {0.5f,0.5f,0.5f,1.0f};
GLfloat specular[] = {0.5f,0.5f,0.5f,1.0f};
GLfloat specular_reflexion_obj[] = {0.3f,0.3f,0.3f,1.0f};
GLubyte shiny_obj = 128;
GLfloat points_sol[3][3]= {{0.0f,0.0f,0.0f},			// Dans le sens trigonom�trique !!!!
							{0.0f,0.0f,50.0f},
							{50.0f,0.0f,0.0f}};
GLfloat collision[200][200];
GLfloat couleur_brouillard[4] = {0.8f,0.8f,0.8f,1.0f};
//d�roulement des animations
/*D�tail des valeurs :
		-> 1 : Avant
		-> 2 : Arri�re
		-> 3 : Strafe gauche avec rotation (permet de faire le tour d'un objet tout en continuant � le regarder)
		-> 4 : Strafe droit avec rotation (idem)
		-> 5 : Haut
		-> 6 : Bas
		-> 7 : Rotation Gauche
		-> 8 : Rotation Droite
		-> 9 : Strafe Gauche
		-> 10 : Strafe Droit
	La deuxi�me ligne du tableau concerne les valeurs du mouvement
	(la valeur d'une rotation est calcul�e par PI/valeur_sp�cifi�e_dans_le_tableau)
*/
int animation_camera[2][MAX_ANIM_CAMERA] = {{1 ,1 ,1 ,1 ,1 ,1 ,7,7,1 ,1 ,1 ,1 ,1 ,8,8,1 ,1 ,1 ,1 ,1 ,1 ,8,8,8,8,9 ,9 ,9 ,9 ,9 ,9 ,9 ,9 ,9 ,9 ,1 ,1 ,1 ,1,8,8,8,8,1,1 ,1 ,1 ,1 ,1 ,1 ,1,7,7,7,7,1 ,1 ,1 ,1 ,1 ,1 ,1 ,7,7,7,7,1 ,1 ,1 ,1,7,7,7,7,1 ,1 ,1 ,0,0,0,0,2,2,2,2,2,2,2 ,9,9},
											{10,10,10,10,10,10,4,4,10,10,10,10,10,4,4,10,10,10,10,10,10,4,4,4,4,10,10,10,10,10,10,10,10,10,10,10,10,10,5,8,8,8,8,5,5,10,10,10,10,10,10,8,8,8,8,10,10,10,10,10,10,10,8,8,8,8,10,10,10,8,8,8,8,8,10,10,10,0,0,0,0,5,5,5,5,5,5,10,5,5}};

void Set_High(GLfloat x, GLfloat z, GLfloat hauteur)
{
	collision[Make_Indice(x)][Make_Indice(z)]=hauteur;
}

/*ATTENTION : les fonctions sivantes doivent imp�rativement �tre d�finies
			-> void load_Textures();			//charge les textures
			-> void Init_Collisions();			//defini les zones de collisions
			-> void Ombres(int val_stencil);	//appelle les diff�rentes fonctions pour cr�er les ombres (dans notre cas, une seule fonction)
			-> void Draw_Scene(int texture);	//Dessine et place les objets (texture vaut soit TEXTURE (dessin textur�), soit SANS_COULEUR (dessin en noir transparent pour les ombres)
			-> void Init_Obj();					//D�fini les diff�rentes CallListes pour le dessin des objets
			-> void DrawLight0();				//Dessine la lampe nb0
	Toutes les autres fonctions sont optionnelles et ne servent qu'� dessiner les objets.
*/

//debut declaration des objets
void Cube(float maxX1,float maxX2, float maxY1, float maxY2, float maxZ1,float maxZ2)
{
	glBegin(GL_QUADS);
		glNormal3f(-1.0f,0.0f,0.0f);		
		glTexCoord2f(maxX1, 0.0f);glVertex3f(-1.0f,-1.0f,1.0f);
		glTexCoord2f(maxX1, maxX2);glVertex3f(-1.0f,1.0f,1.0f);
		glTexCoord2f(0.0f, maxX2);glVertex3f(-1.0f,1.0f,-1.0f);
		glTexCoord2f(0.0f, 0.0f);glVertex3f(-1.0f,-1.0f,-1.0f);

		glNormal3f(0.0f,0.0f,-1.0f);
		glTexCoord2f(maxZ1, 0.0f);glVertex3f(-1.0f,-1.0f,-1.0f);
		glTexCoord2f(maxZ1, maxZ2);glVertex3f(-1.0f,1.0f,-1.0f);
		glTexCoord2f(0.0f, maxZ2);glVertex3f(1.0f,1.0f,-1.0f);
		glTexCoord2f(0.0f, 0.0f);glVertex3f(1.0f,-1.0f,-1.0f);
							
		glNormal3f(1.0f,0.0f,0.0f);		
		glTexCoord2f(maxX1, 0.0f);glVertex3f(1.0f,-1.0f,1.0f);
		glTexCoord2f(0.0f, 0.0f);glVertex3f(1.0f,-1.0f,-1.0f);
		glTexCoord2f(0.0f, maxX2);glVertex3f(1.0f,1.0f,-1.0f);
		glTexCoord2f(maxX1, maxX2);glVertex3f(1.0f,1.0f,1.0f);

		glNormal3f(0.0f,0.0f,1.0f);
		glTexCoord2f(maxZ1, 0.0f);glVertex3f(-1.0f,-1.0f,1.0f);
		glTexCoord2f(0.0f, 0.0f);glVertex3f(1.0f,-1.0f,1.0f);
		glTexCoord2f(0.0f, maxZ2);glVertex3f(1.0f,1.0f,1.0f);
		glTexCoord2f(maxZ1, maxZ2);glVertex3f(-1.0f,1.0f,1.0f);
		
	glEnd();
	glBegin(GL_QUADS);
		glNormal3f(0.0f,1.0f,0.0f);
		glTexCoord2f(maxY1, 0.0f);glVertex3f(1.0f,1.0f,-1.0f);
		glTexCoord2f(0.0f, 0.0f);glVertex3f(-1.0f,1.0f,-1.0f);
		glTexCoord2f(0.0f, maxY2);glVertex3f(-1.0f,1.0f,1.0f);
		glTexCoord2f(maxY1, maxY2);glVertex3f(1.0f,1.0f,1.0f);

		glNormal3f(0.0f,-1.0f,0.0f);
		glTexCoord2f(maxY1, 0.0f);glVertex3f(1.0f,-1.0f,-1.0f);
		glTexCoord2f(maxY1, maxY2);glVertex3f(1.0f,-1.0f,1.0f);
		glTexCoord2f(0.0f, maxY2);glVertex3f(-1.0f,-1.0f,1.0f);
		glTexCoord2f(0.0f, 0.0f);glVertex3f(-1.0f,-1.0f,-1.0f);
	glEnd();
}

void DrawRoue()
{
	GLfloat x,y,z,angle;
	GLfloat fStep = (float)PI/6.0f;
	GLfloat fWidth = 1.0f;
	GLfloat fSize = 4.0f;
	GLfloat vNormal[3];

	for(z = 0.0f; z <= fWidth; z+= fWidth)
		{
			if(z > 0.0)
			{
					glFrontFace(GL_CW);
					glNormal3f(0.0f, 0.0f, 1.0f);
			}
			else glNormal3f(0.0f, 0.0f, -1.0f);

			glBegin(GL_TRIANGLE_FAN);
				glVertex3f(0.0f, 0.0f, z);
				for(angle = 0.0f; angle < (2.0f*(float)PI); angle += fStep)
				{
						x = fSize*fsin(angle);
						y = fSize*fcos(angle);
						glVertex3f(x, y, z);
				}
			glEnd();
		}

	glFrontFace(GL_CCW);	// Switch back to counter clock wise
	for(angle = 0.0f; angle < 3.0f*(float)PI; angle += fStep)
		{
			x = fSize*fsin(angle);
			y = fSize*fcos(angle);

			glBegin(GL_QUADS);
				vNormal[0] = x;
				vNormal[1] = y;
				vNormal[2] = 0.0f;
				Vecteur_Unite(vNormal);
				glNormal3fv(vNormal);

				glVertex3f(x, y, 0.0f);
				glVertex3f(x, y, fWidth);

				x = fSize*fsin(angle+fStep);
				y = fSize*fcos(angle+fStep);
				
				vNormal[0] = x;
				vNormal[1] = y;
				vNormal[2] = fWidth;
				Vecteur_Unite(vNormal);

				glNormal3fv(vNormal);
				glVertex3f(x, y, fWidth);
				glVertex3f(x, y, 0.0f);
			glEnd();
		}
}

void Cylindre(GLfloat fHeight, GLfloat fRadius, int bords, int exterieur)
{
	GLfloat vNormal[3];

	GLfloat x,z,angle;
	GLfloat fStep = (float)PI/bords;

	if (!exterieur) glFrontFace(GL_CW);
	glBegin(GL_QUAD_STRIP);
		for(angle = 0; angle < 2.0f*PI; angle += fStep)
			{
				x = fRadius*fsin(angle);
				z = fRadius*fcos(angle);

				if (exterieur)
				{
					vNormal[0] = x;
					vNormal[1] = fHeight;
					vNormal[2] = z;
				}
				else
				{
					vNormal[0] = -x;
					vNormal[1] = fHeight;
					vNormal[2] = -z;
				}
				Vecteur_Unite(vNormal);
				glNormal3fv(vNormal);
				glTexCoord2f(0.0f, 1.0f);glVertex3f(x, fHeight, z );
				glTexCoord2f(0.0f, 0.0f);glVertex3f(x, -fHeight, z);
			}
	glEnd();
	glFrontFace(GL_CCW);
}

void Base_Pilier()
{
	glPushMatrix();
		glPushMatrix();
			glEnable(GL_NORMALIZE);
			glTranslatef(0.0f, 0.5f, 0.0f);
			glScalef(4.0f, 0.65f, 4.0f);
			Cube(2.0f,0.5f,2.0f,2.0f,2.0f,0.5f);
			glDisable(GL_NORMALIZE);
		glPopMatrix();
		glTranslatef(0.0f,20.0f,0.0f);
		glPushMatrix();
			glEnable(GL_NORMALIZE);
			glTranslatef(0.0f, 0.5f, 0.0f);
			glScalef(4.0f, 0.65f, 4.0f);
			Cube(2.0f,0.5f,2.0f,2.0f,2.0f,0.5f);
			glDisable(GL_NORMALIZE);
		glPopMatrix();
	glPopMatrix();
}

void DrawJet(BOOL bShadow)
{
	float normal[3];

	// Dessin du nez de l'avion
	if(!bShadow) glRGB(0, 255, 0);
	glBegin(GL_TRIANGLES);
		glNormal3f(0.0f, -1.0f, 0.0f);
		glVertex3f(0.0f, 0.0f, 60.0f);
		glVertex3f(-15.0f, 0.0f, 30.0f);
		glVertex3f(15.0f,0.0f,30.0f);

		{
			static float v[3][3] =	{{ 15.0f, 0.0f, 30.0f},
									{ 0.0f, 15.0f, 30.0f},
									{ 0.0f, 0.0f,	60.0f}};

			Normale(v,normal);
			glNormal3fv(normal);
			glVertex3fv(v[0]);
			glVertex3fv(v[1]);
			glVertex3fv(v[2]);
		}	
		{
			static float v[3][3] = {{ 0.0f, 0.0f, 60.0f },
									{ 0.0f, 15.0f, 30.0f },
									{ -15.0f, 0.0f, 30.0f }};
			Normale(v,normal);
			glNormal3fv(normal);
			glVertex3fv(v[0]);
			glVertex3fv(v[1]);
			glVertex3fv(v[2]);
		}

		// Corps de l'avion
		if(!bShadow) glRGB(192,192,192); //couleur grise
		{
			static float v[3][3] = {{ -15.0f,0.0f,30.0f },
								 { 0.0f, 15.0f, 30.0f },
								 { 0.0f, 0.0f, -56.0f }};
			Normale(v,normal);
			glNormal3fv(normal);
			glVertex3fv(v[0]);
			glVertex3fv(v[1]);
			glVertex3fv(v[2]);
		}
		{
			static float v[3][3] = {{ 0.0f, 0.0f, -56.0f },
									 { 0.0f, 15.0f, 30.0f },
									 { 15.0f,0.0f,30.0f }};
			Normale(v,normal);
			glNormal3fv(normal);
			glVertex3fv(v[0]);
			glVertex3fv(v[1]);
			glVertex3fv(v[2]);	
		}
		glNormal3f(0.0f, -1.0f, 0.0f);
		glVertex3f(15.0f,0.0f,30.0f);
		glVertex3f(-15.0f, 0.0f, 30.0f);
		glVertex3f(0.0f, 0.0f, -56.0f);

	//Aile gauche
	if(!bShadow) glRGB(128,128,128);
	{
			static float v[3][3] = {{ 0.0f,2.0f,27.0f },
								 { -60.0f, 2.0f, -8.0f },
								 { 60.0f, 2.0f, -8.0f }};
			Normale(v,normal);
			glNormal3fv(normal);
			glVertex3fv(v[0]);
			glVertex3fv(v[1]);
			glVertex3fv(v[2]);
	}
	{
			static float v[3][3] =    {{ 60.0f, 2.0f, -8.0f},
									{0.0f, 7.0f, -8.0f},
									{0.0f,2.0f,27.0f }};
			Normale(v,normal);
			glNormal3fv(normal);
			glVertex3fv(v[0]);
			glVertex3fv(v[1]);
			glVertex3fv(v[2]);
	}
	{
			static float v[3][3] = {{60.0f, 2.0f, -8.0f},
									{-60.0f, 2.0f, -8.0f},
									{0.0f,7.0f,-8.0f }};
			Normale(v,normal);
			glNormal3fv(normal);
			glVertex3fv(v[0]);
			glVertex3fv(v[1]);
			glVertex3fv(v[2]);
	}
	{
			static float v[3][3] = {{0.0f,2.0f,27.0f},
									 {0.0f, 7.0f, -8.0f},
									 {-60.0f, 2.0f, -8.0f}};
			Normale(v,normal);
			glNormal3fv(normal);
			glVertex3fv(v[0]);
			glVertex3fv(v[1]);
			glVertex3fv(v[2]);
	}
	// Queue de l'vion
		if(!bShadow) glRGB(255,255,0);
		glNormal3f(0.0f, -1.0f, 0.0f);
		glVertex3f(-30.0f, -0.50f, -57.0f);
		glVertex3f(30.0f, -0.50f, -57.0f);
		glVertex3f(0.0f,-0.50f,-40.0f);
		{
			static float v[3][3] = {{ 0.0f,-0.5f,-40.0f },
							{30.0f, -0.5f, -57.0f},
							{0.0f, 4.0f, -57.0f }};
			Normale(v,normal);
			glNormal3fv(normal);
			glVertex3fv(v[0]);
			glVertex3fv(v[1]);
			glVertex3fv(v[2]);
		}
		{
			static float v[3][3] = {{ 0.0f, 4.0f, -57.0f },
									{ -30.0f, -0.5f, -57.0f },
									{ 0.0f,-0.5f,-40.0f }};
			Normale(v,normal);
			glNormal3fv(normal);
			glVertex3fv(v[0]);
			glVertex3fv(v[1]);
			glVertex3fv(v[2]);
		}
		{
			static float v[3][3] = {{ 30.0f,-0.5f,-57.0f },
									{ -30.0f, -0.5f, -57.0f },
									{ 0.0f, 4.0f, -57.0f }};
			Normale(v,normal);
			// derri�re de la queue
			glNormal3fv(normal);
			glVertex3fv(v[0]);
			glVertex3fv(v[1]);
			glVertex3fv(v[2]);
		}
		{
			static float v[3][3] = {{ 0.0f,0.5f,-40.0f },
									{ 3.0f, 0.5f, -57.0f },
									{ 0.0f, 25.0f, -65.0f }};
			Normale(v,normal);
			// Partie gauche de la queue
			if(!bShadow) glRGB(255,0,0);
			glNormal3fv(normal);
			glVertex3fv(v[0]);
			glVertex3fv(v[1]);
			glVertex3fv(v[2]);
		}
		{
			static float v[3][3] = {{ 0.0f, 25.0f, -65.0f },
									{ -3.0f, 0.5f, -57.0f},
									{ 0.0f,0.5f,-40.0f }};
			Normale(v,normal);
			glNormal3fv(normal);
			glVertex3fv(v[0]);
			glVertex3fv(v[1]);
			glVertex3fv(v[2]);
		}
		{
			static float v[3][3] = {{ 3.0f,0.5f,-57.0f },
									{ -3.0f, 0.5f, -57.0f },
									{ 0.0f, 25.0f, -65.0f }};
			Normale(v,normal);
			glNormal3fv(normal);
			glVertex3fv(v[0]);
			glVertex3fv(v[1]);
			glVertex3fv(v[2]);
		}
	glEnd();
}

void DrawGround(int uniforme)
{
	GLfloat w, r;
	Texture_on(HERBE);
	glNormal3f(0.0f,1.0f, 0.0f);
	glBegin(GL_QUADS);
		if (!uniforme)
		{
			for (w=-X_LIMITE;w<X_LIMITE;w+=CARREAU)
				for (r=-Z_LIMITE;r<Z_LIMITE;r+=CARREAU)
				{
					glTexCoord2f(1.0f, 0.0f);glVertex3f(w,0,r);
					glTexCoord2f(1.0f, 1.0f);glVertex3f(w,0,r+CARREAU);
					glTexCoord2f(0.0f, 1.0f);glVertex3f(w+CARREAU,0,r+CARREAU);
					glTexCoord2f(0.0f, 0.0f);glVertex3f(w+CARREAU,0,r);
				}
		}
		else
		{
			glVertex3f(-X_LIMITE,0.0f,-Z_LIMITE);
			glVertex3f(-X_LIMITE,0.0f,Z_LIMITE);
			glVertex3f(X_LIMITE,0.0f,Z_LIMITE);
			glVertex3f(X_LIMITE,0.0f,-Z_LIMITE);
		}
	glEnd();
	Texture_off();
}

void DrawLight0()
{
	glDisable(GL_LIGHTING);
		glRGB(255,255,255);
		glPushMatrix();
			glTranslatef(light0_pos[0],light0_pos[1],light0_pos[2]);
			auxSolidSphere(3.0f);
		glPopMatrix();
	glEnable(GL_LIGHTING);
}

void DrawTree(int level, int max_level, int couleur)
{
  if (level == max_level) 
  {
	  glScalef(25.0f,25.0f,25.0f);
	  glPushMatrix();    
        glRotatef(110 + 40, 0, 1, 0);
        glRotatef(30 + 20, 0, 0, 1);
		glCallList(FEUILLE+couleur);
      glPopMatrix();

	  glPushMatrix();    
        glRotatef(80 + 40, 0, 1, 0);
        glRotatef(-30 + 20, 0, 0, 1);
		glCallList(FEUILLE+couleur);
      glPopMatrix();

	  glPushMatrix();    
        glRotatef(140 + 40, 0, 1, 0);
        glRotatef(-25 + 20, 0, 0, 1);
		glCallList(FEUILLE+couleur);
      glPopMatrix();

	  glPushMatrix();    
        glRotatef(110 + 40, 0, 1, 0);
        glRotatef(30 + 20, 0, 0, 1);
		glCallList(FEUILLE+couleur);
      glPopMatrix();

      glPushMatrix();
        glRotatef(-130 + 40, 0, 1, 0);
        glRotatef(30 + 20, 0, 0, 1);
       	glCallList(FEUILLE+couleur);
      glPopMatrix();

      glPushMatrix();
        glRotatef(-20 + 40, 0, 1, 0);
        glRotatef(30 + 20, 0, 0, 1);
        glCallList(FEUILLE+couleur);
      glPopMatrix();
  }
  else 
  {
    if (level) glCallList(BRANCHE+couleur);
    glPushMatrix();
    glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
    glTranslatef(0.0f, 6.0f, 0.0f);
    glScalef(0.5f, 0.5f, 0.5f);

      glPushMatrix();    
        glRotatef(110 + 40, 0, 1, 0);
        glRotatef(30 + 20, 0, 0, 1);
		glTranslatef(0.0f, 6.0f, 0.0f);
        DrawTree(level + 1,max_level,couleur);
      glPopMatrix();

      glPushMatrix();
        glRotatef(-130 + 40, 0, 1, 0);
        glRotatef(30 + 20, 0, 0, 1);
		glTranslatef(0.0f, 6.0f, 0.0f);
        DrawTree(level + 1,max_level,couleur);
      glPopMatrix();

      glPushMatrix();
        glRotatef(-20 + 40, 0, 1, 0);
        glRotatef(30 + 20, 0, 0, 1);
		glTranslatef(0.0f, 6.0f, 0.0f);
        DrawTree(level + 1,max_level, couleur);
      glPopMatrix();
    glPopMatrix();
  }
}

void Cercle(GLfloat fSize, float angle_max, int bords)
{
	GLfloat x,y,angle;
	GLfloat fStep = (float)PI/bords;

	glNormal3f(0.0f, 0.0f, -1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex3f(0.0f, 0.0f, 0.0f);
		for(angle = 0.0f; angle < angle_max; angle += fStep)
		{
			x = fSize*fsin(angle);
			y = fSize*fcos(angle);
			glTexCoord2f(0.5f*fsin(angle)+0.5f,0.5f*fcos(angle)+0.5f);
			glVertex3f(x, y,0);
		}
	glEnd();
}

///////////////////////////////////////////////////////////////////////////////
void Init_Obj()
{	
	glNewList(BASE_PILIER, GL_COMPILE);
		Base_Pilier();
	glEndList();

	glNewList(CORPS_PILIER, GL_COMPILE);
		glPushMatrix();
			glTranslatef(0.0f,10.0f,0.0f);
			Cylindre(10.0f, 3.0f,6,1);
		glPopMatrix();
	glEndList();
	
	glNewList(BASE_PILIER+TEXTURE, GL_COMPILE);
		glRGB(128,128,128);
		glCallList(BASE_PILIER);
		glPushMatrix();
			glTranslatef(0.0f,20.5f,0.0f);
			glCallList(BASE_PILIER);
		glPopMatrix();
	glEndList();

	glNewList(CORPS_PILIER+TEXTURE, GL_COMPILE);
		glRGB(128,128,128);
		glCallList(CORPS_PILIER);
	glEndList();

	glNewList(PILIER, GL_COMPILE);
		glCallList(BASE_PILIER);
		glCallList(CORPS_PILIER);
	glEndList();

	glNewList(PILIER+TEXTURE, GL_COMPILE);
		glCallList(BASE_PILIER+TEXTURE);
		glCallList(CORPS_PILIER+TEXTURE);
	glEndList();

	glNewList(SOL, GL_COMPILE);
		DrawGround(0);
	glEndList();

	glNewList(SOL_UNIFORME, GL_COMPILE);
		DrawGround(1);
	glEndList();

	glNewList(ROUE, GL_COMPILE);
		DrawRoue();
	glEndList();

	glNewList(CORPS_REMORQUE,GL_COMPILE);
		glPushMatrix();
			glTranslatef(-1.0f,0.0f,0.0f);
				glEnable(GL_NORMALIZE);
				glScalef(13.0f,2.5f,10.0f);
				Cube(0,0,0,0,0,0);
				glDisable(GL_NORMALIZE);
		glPopMatrix();
	glEndList();

	glNewList(REMORQUE, GL_COMPILE);
		glPushMatrix();
			glTranslatef(0.0f,4.0f,0.0f);
			glCallList(CORPS_REMORQUE);
			glPushMatrix();
				glTranslatef(9.0f, 0.0f, 10.0f);
				glCallList(ROUE);
				glTranslatef(-20.0f, 0.0f, 0.0f);
				glCallList(ROUE);
				glTranslatef(0.0f, 0.0f, -21.0f);
				glCallList(ROUE);
				glTranslatef(20.0f, 0.0f, 0.0f);
				glCallList(ROUE);
			glPopMatrix();
		glPopMatrix();		
	glEndList();

	glNewList(REMORQUE+TEXTURE, GL_COMPILE);
		glRGB(0,0,255);
		glPushMatrix();
			glTranslatef(0.0f,4.0f,0.0f);
			glCallList(CORPS_REMORQUE);
			glPushMatrix();
				glRGB(128,128,128);
				glTranslatef(9.0f, 0.0f, 10.0f);
				glCallList(ROUE);
				glTranslatef(-20.0f, 0.0f, 0.0f);
				glCallList(ROUE);
				glTranslatef(0.0f, 0.0f, -21.0f);
				glCallList(ROUE);
				glTranslatef(20.0f, 0.0f, 0.0f);
				glCallList(ROUE);
			glPopMatrix();
		glPopMatrix();
	glEndList();

	glNewList(AVION,GL_COMPILE);
		DrawJet(1);
	glEndList();

	glNewList(AVION+TEXTURE,GL_COMPILE);
		DrawJet(0);
	glEndList();

	glNewList(FEUILLE,GL_COMPILE);
		glBegin(GL_TRIANGLES);
		  glNormal3f(0.0f, 1.0f, 0.0f);
		  glVertex3f(0.0f,0.0f,0.0f);
		  glVertex3f(-0.5f,0.0f,0.5f);
		  glVertex3f(0.5f,0.0f,0.5f);

		  glNormal3f(0.0f, 1.0f, 0.0f);
		  glVertex3f(-0.5f,0.0f,0.5f);
		  glVertex3f(0.5f,0.0f,0.5f);
		  glVertex3f(0.0f,0.0f,0.0f);
		glEnd();
	 glEndList();

	glNewList(FEUILLE+TEXTURE,GL_COMPILE);
		glRGB(0,200,0);
		glCallList(FEUILLE);
	glEndList();

	glNewList(BRANCHE,GL_COMPILE);
		Cylindre(6.0f,1.0f,6,1);
	glEndList();

	glNewList(BRANCHE+TEXTURE,GL_COMPILE);
		glRGB(132,103,75);
		glCallList(BRANCHE);
	glEndList();

	glNewList(ARBRE,GL_COMPILE);
		glPushMatrix();
			glTranslatef(0.0f,3.0f,0.0f);
			Cylindre(3.0f,0.90f,6,1);
		glPopMatrix();
		DrawTree(0,3,SANS_COULEUR);
	glEndList();

	glNewList(ARBRE+TEXTURE,GL_COMPILE);
		glRGB(132,103,75);
		glPushMatrix();
			glTranslatef(0.0f,3.0f,0.0f);
			Cylindre(3.0f,0.90f,6,1);
		glPopMatrix();
		glEnable(GL_NORMALIZE);
		DrawTree(0,3,TEXTURE);
		glDisable(GL_NORMALIZE);
	glEndList();

	glNewList(PAN_TOIT1, GL_COMPILE);
		glBegin(GL_QUADS);
		{
			static float v[3][3] = {{0.0f,0.0f,1.0f},
									 {2.0f,0.0f,1.0f},
									 {1.5f,1.0f,0.0f}};
			float normal[3];

			Normale(v,normal);
			glNormal3fv(normal);
			glTexCoord2f(0.0f, 0.0f);glVertex3fv(v[0]);
			glTexCoord2f(0.0f, 1.0f);glVertex3fv(v[1]);
			glTexCoord2f(1.0f, 1.0f);glVertex3fv(v[2]);
			glTexCoord2f(1.0f, 0.0f);glVertex3f(0.5f,1.0f,0.0f);
		}
		glEnd();
	glEndList();

	glNewList(PAN_TOIT2, GL_COMPILE);
		glBegin(GL_TRIANGLES);
		{
			static float v[3][3] = {{0.0f,0.0f,1.0f},
									 {0.5f,1.0f,0.0f},
									 {0.0f,0.0f,-1.0f}};
			float normal[3];

			Normale(v,normal);
			glNormal3fv(normal);
			glTexCoord2f(0.0f, 0.0f);glVertex3fv(v[0]);
			glTexCoord2f(0.5f, 0.5f);glVertex3fv(v[1]);
			glTexCoord2f(1.0f, 0.0f);glVertex3fv(v[2]);
		}
		glEnd();
	glEndList();

	glNewList(TOIT,GL_COMPILE);
		glEnable(GL_NORMALIZE);
		glPushMatrix();
			glCallList(PAN_TOIT1);
			glScalef(1.0f,1.0f,-1.0f);
			glFrontFace(GL_CW);
			glCallList(PAN_TOIT1);
			glFrontFace(GL_CCW);
		glPopMatrix();
		glPushMatrix();
			glCallList(PAN_TOIT2);
			glTranslatef(2.0f,0.0f,0.0f);
			glScalef(-1.0f,1.0f,1.0f);
			glFrontFace(GL_CW);
			glCallList(PAN_TOIT2);
			glFrontFace(GL_CCW);
		glPopMatrix();
		glDisable(GL_NORMALIZE);
	glEndList();
	
	glNewList(TEMPLE,GL_COMPILE);
		glPushMatrix();
			glEnable(GL_NORMALIZE);
			glScalef(20.0f,2.0f,40.0f);
			glTranslatef(0.0f,1.0f,0.0f);
			Cube(20.0f,1.0f,1.0f,1.0f,10.0f,1.0f);
			glDisable(GL_NORMALIZE);
		glPopMatrix();
		glPushMatrix();
			glEnable(GL_NORMALIZE);
			glScalef(20.0f,2.0f,40.0f);
			glTranslatef(0.0f,14.0f,0.0f);
			Cube(20.0f,1.0f,1.0f,1.0f,10.0f,1.0f);
			glDisable(GL_NORMALIZE);
		glPopMatrix();
		glPushMatrix();
			glTranslatef(15.0f,4.0f,0.0f);
			glCallList(PILIER);
			glTranslatef(0.0f,0.0f,35.0f);
			glCallList(PILIER);
			glTranslatef(0.0f,0.0f,-70.0f);
			glCallList(PILIER);
			glTranslatef(-30.0f,0.0f,35.0f);
			glCallList(PILIER);
			glTranslatef(0.0f,0.0f,35.0f);
			glCallList(PILIER);
			glTranslatef(0.0f,0.0f,-70.0f);
			glCallList(PILIER);
		glPopMatrix();
		glPushMatrix();
			glEnable(GL_NORMALIZE);
			glScalef(20.0f,10.0f,40.0f);
			glTranslatef(-1.0f,3.0f,0.0f);
			glCallList(TOIT);
			glDisable(GL_NORMALIZE);
		glPopMatrix();
	glEndList();

	glNewList(TEMPLE+TEXTURE,GL_COMPILE);
		Texture_on(MARBRE);
		glPushMatrix();
			glEnable(GL_NORMALIZE);
			glScalef(20.0f,2.0f,40.0f);
			glTranslatef(0.0f,1.0f,0.0f);
			Cube(20.0f,1.0f,1.0f,1.0f,10.0f,1.0f);
			glDisable(GL_NORMALIZE);
		glPopMatrix();
		glPushMatrix();
			glEnable(GL_NORMALIZE);
			glScalef(20.0f,2.0f,40.0f);
			glTranslatef(0.0f,14.0f,0.0f);
			Cube(20.0f,1.0f,1.0f,1.0f,10.0f,1.0f);
			glDisable(GL_NORMALIZE);
		glPopMatrix();
		Texture_off();
		glRGB(200,200,200);
		glPushMatrix();
			glTranslatef(15.0f,4.0f,0.0f);
			glCallList(PILIER);
			glTranslatef(0.0f,0.0f,35.0f);
			glCallList(PILIER);
			glTranslatef(0.0f,0.0f,-70.0f);
			glCallList(PILIER);
			glTranslatef(-30.0f,0.0f,35.0f);
			glCallList(PILIER);
			glTranslatef(0.0f,0.0f,35.0f);
			glCallList(PILIER);
			glTranslatef(0.0f,0.0f,-70.0f);
			glCallList(PILIER);
		glPopMatrix();
		Texture_on(MARBRE);
		glPushMatrix();
			glEnable(GL_NORMALIZE);
			glScalef(20.0f,10.0f,40.0f);
			glTranslatef(-1.0f,3.0f,0.0f);
			glCallList(TOIT);
			glDisable(GL_NORMALIZE);
		glPopMatrix();
		Texture_off();
	glEndList();

	glNewList(MIRROIR_DEMI,GL_COMPILE);
		Cercle(4.0f,PI,9);
	glEndList();

	glNewList(MIRROIR_PILE,GL_COMPILE);
		glPushMatrix();
			glTranslatef(0.0f,0.5f,0.0f);
			glRotatef(90.0f,0.0f,0.0f,1.0f);
			glCallList(MIRROIR_DEMI);
			glTranslatef(-5.0f,0.0f,0.0f);
			glRotatef(180.0f,0.0f,0.0f,1.0f);
			glCallList(MIRROIR_DEMI);
		glPopMatrix();
		glPushMatrix();
			glTranslatef(0.0f,-5.0f,0.0f);
			glCallList(MIRROIR_CARRE);
		glPopMatrix();
	glEndList();

	glNewList(MIRROIR_FACE,GL_COMPILE);
		glPushMatrix();	
			glFrontFace(GL_CW);
			glScalef(1.0f,1.0f,-1.0f);
			glCallList(MIRROIR_PILE);
			glFrontFace(GL_CCW);
		glPopMatrix();
	glEndList();

	glNewList(MIRROIR,GL_COMPILE);
		glPushMatrix();
			glTranslatef(-5.0f,8.0f,101.0f);
			glRotatef(90.0f,0.0f,0.0f,1.0f);
			glScalef(2.0f,3.0f,1.0f);
			glCallList(MIRROIR_PILE);
		glPopMatrix();
	glEndList();

	glNewList(MIRROIR_CARRE,GL_COMPILE);
		glBegin(GL_QUADS);
			glNormal3f(0.0f,0.0f,-1.0f);
			glVertex3f(-4.0f,0.0f,0.0f);
			glVertex3f(-4.0f,6.0f,0.0f);
			glVertex3f(4.0f,6.0f,0.0f);
			glVertex3f(4.0f,0.0f,0.0f);
		glEnd();
	glEndList();

	glNewList(MIRROIR+TEXTURE,GL_COMPILE);
		glColor4f(0.60f,0.60f,0.60f,0.25f);
		glCallList(MIRROIR);
	glEndList();

	glNewList(MARCHE,GL_COMPILE);
		glBegin(GL_QUADS);
			glNormal3f(0.0f,-1.0f,0.0f);
			glVertex3f(0.0f,1.0f,0.0f);
			glVertex3f(0.0f,1.0f,2.0f);
			glVertex3f(10.0f,1.0f,2.0f);
			glVertex3f(10.0f,1.0f,0.0f);

			glNormal3f(0.0f,0.0f,1.0f);
			glVertex3f(0.0f,1.0f,2.0f);
			glVertex3f(0.0f,0.0f,2.0f);
			glVertex3f(10.0f,0.0f,2.0f);
			glVertex3f(10.0f,1.0f,2.0f);

			glNormal3f(-1.0f,0.0f,0.0f);
			glVertex3f(0.0f,1.0f,0.0f);
			glVertex3f(0.0f,0.0f,0.0f);
			glVertex3f(0.0f,0.0f,2.0f);
			glVertex3f(0.0f,1.0f,2.0f);

			glNormal3f(1.0f,0.0f,0.0f);
			glVertex3f(10.0f,1.0f,0.0f);
			glVertex3f(10.0f,1.0f,2.0f);
			glVertex3f(10.0f,0.0f,2.0f);
			glVertex3f(10.0f,0.0f,0.0f);			
			
		glEnd();
	glEndList();

	glNewList(MARCHE+TEXTURE,GL_COMPILE);
		glRGB(255,0,0);
		glCallList(MARCHE);
	glEndList();

	glNewList(ESCALIER,GL_COMPILE);
		glPushMatrix();
			glCallList(MARCHE);
			glTranslatef(0.0f,1.0f,-2.0f);
			glCallList(MARCHE);
			glTranslatef(0.0f,1.0f,-2.0f);
			glCallList(MARCHE);
			glTranslatef(0.0f,1.0f,-2.0f);
			glCallList(MARCHE);
		glPopMatrix();
	glEndList();

	glNewList(ESCALIER+TEXTURE,GL_COMPILE);
		glRGB(255,0,0);
		glCallList(ESCALIER);
	glEndList();

	glNewList(CIEL,GL_COMPILE);
		glNormal3f(0.0f,-1.0f,0.0f);
		Texture_on(CIEL_T);
		glPushMatrix();
			glBegin(GL_QUADS);	
				glTexCoord2f(1.0f, 0.0f);glVertex3f(X_LIMITE_DECOR,100.0f,Z_LIMITE_DECOR);
				glTexCoord2f(1.0f, 1.0f);glVertex3f(-X_LIMITE_DECOR,100.0f,Z_LIMITE_DECOR);
				glTexCoord2f(0.0f, 1.0f);glVertex3f(-X_LIMITE_DECOR,100.0f,0.0f);
				glTexCoord2f(0.0f, 0.0f);glVertex3f(X_LIMITE_DECOR,100.0f,0.0f);

				glTexCoord2f(1.0f, 0.0f);glVertex3f(X_LIMITE_DECOR,100.0f,0.0f);
				glTexCoord2f(1.0f, 1.0f);glVertex3f(-X_LIMITE_DECOR,100.0f,0.0f);
				glTexCoord2f(0.0f, 1.0f);glVertex3f(-X_LIMITE_DECOR,100.0f,-Z_LIMITE_DECOR);
				glTexCoord2f(0.0f, 0.0f);glVertex3f(X_LIMITE_DECOR,100.0f,-Z_LIMITE_DECOR);
			glEnd();
		glPopMatrix();
		Texture_off();
	glEndList();

	glNewList(CIEL_NUIT,GL_COMPILE);
		glDisable(GL_LIGHTING);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);
		Texture_on(CIEL_T);
		glPushMatrix();
			glBegin(GL_QUADS);	
				glTexCoord2f(1.0f, 0.0f);glVertex3f(X_LIMITE_DECOR,100.0f,-Z_LIMITE_DECOR);
				glTexCoord2f(1.0f, 1.0f);glVertex3f(X_LIMITE_DECOR,100.0f,Z_LIMITE_DECOR);
				glTexCoord2f(0.0f, 1.0f);glVertex3f(0.0f,100.0f,Z_LIMITE_DECOR);
				glTexCoord2f(0.0f, 0.0f);glVertex3f(0.0f,100.0f,-Z_LIMITE_DECOR);

				glTexCoord2f(0.0f, 1.0f);glVertex3f(0.0f,100.0f,-Z_LIMITE_DECOR);
				glTexCoord2f(0.0f, 0.0f);glVertex3f(0.0f,100.0f,Z_LIMITE_DECOR);
				glTexCoord2f(1.0f, 0.0f);glVertex3f(-X_LIMITE_DECOR,100.0f,Z_LIMITE_DECOR);
				glTexCoord2f(1.0f, 1.0f);glVertex3f(-X_LIMITE_DECOR,100.0f,-Z_LIMITE_DECOR);
			glEnd();
		glPopMatrix();
		glEnable(GL_LIGHTING);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		Texture_off();
	glEndList();

	glNewList(CHEMIN,GL_COMPILE);
		glBegin(GL_QUADS);
		{	
			int w,r;
			
			for(r=0;r<2;r++)
			{
				for(w=0;w<6;w++)
				{
					glNormal3f(0.0f,1.0f,0.0f);
					glTexCoord2f(1.0f, 0.0f);glVertex3f(8.0f+r*8.0f,0.05f,0.0f+w*8.0f);
					glTexCoord2f(1.0f, 1.0f);glVertex3f(0.0f+r*8.0f,0.05f,0.0f+w*8.0f);
					glTexCoord2f(0.0f, 1.0f);glVertex3f(0.0f+r*8.0f,0.05f,8.0f+w*8.0f);
					glTexCoord2f(0.0f, 0.0f);glVertex3f(8.0f+r*8.0f,0.05f,8.0f+w*8.0f);
				}	
			}
			glTexCoord2f(1.0f, 0.0f);glVertex3f(16.0f,0.05f,48.0f);
			glTexCoord2f(1.0f, 1.0f);glVertex3f(0.0f,0.05f,48.0f);
			glTexCoord2f(0.0f, 1.0f);glVertex3f(0.0f,0.05f,52.0f);
			glTexCoord2f(0.0f, 0.0f);glVertex3f(16.0f,0.05f,52.0f);
		}
		glEnd();
	glEndList();

	glNewList(CHEMIN+TEXTURE,GL_COMPILE);
		Texture_on(CAILLOU);
		glCallList(CHEMIN);
		Texture_off();
	glEndList();

	glNewList(PETIT_MUR,GL_COMPILE);
		glBegin(GL_QUADS);
			glNormal3f(1.0f,0.0f,0.0f);
			glTexCoord2f(5.0f, 4.0f);glVertex3f(0.0f,8.0f,0.0f);
			glTexCoord2f(0.0f, 4.0f);glVertex3f(0.0f,8.0f,10.0f);
			glTexCoord2f(0.0f, 0.0f);glVertex3f(0.0f,0.0f,10.0f);
			glTexCoord2f(5.0f, 0.0f);glVertex3f(0.0f,0.0f,0.0f);

			glNormal3f(-1.0f,0.0f,0.0f);
			glTexCoord2f(5.0f, 0.0f);glVertex3f(0.0f,8.0f,0.0f);
			glTexCoord2f(5.0f, 4.0f);glVertex3f(0.0f,0.0f,0.0f);
			glTexCoord2f(0.0f, 4.0f);glVertex3f(0.0f,0.0f,10.0f);
			glTexCoord2f(0.0f, 0.0f);glVertex3f(0.0f,8.0f,10.0f);
		glEnd();
	glEndList();

	glNewList(MUR,GL_COMPILE);
		glPushMatrix();
			glCallList(PETIT_MUR);
			glTranslatef(0.0f,0.0f,10.0f);
			glCallList(PETIT_MUR);
		glPopMatrix();		
	glEndList();

	glNewList(PORTE,GL_COMPILE);
		glBegin(GL_QUADS);
			glNormal3f(-1.0f,0.0f,0.0f);
			glTexCoord2f(2.0f, 0.0f);glVertex3f(0.0f,6.0f,0.0f);
			glTexCoord2f(2.0f, 3.0f);glVertex3f(0.0f,0.0f,0.0f);
			glTexCoord2f(0.0f, 3.0f);glVertex3f(0.0f,0.0f,4.0f);
			glTexCoord2f(0.0f, 0.0f);glVertex3f(0.0f,6.0f,4.0f);
		glEnd();
		glDisable(GL_CULL_FACE);
		glBegin(GL_QUADS);
			glNormal3f(1.0f,0.0f,0.0f);
			glTexCoord2f(2.0f, 0.0f);glVertex3f(0.0f,6.0f,0.0f);
			glTexCoord2f(2.0f, 3.0f);glVertex3f(0.0f,0.0f,0.0f);
			glTexCoord2f(0.0f, 3.0f);glVertex3f(0.0f,0.0f,4.0f);
			glTexCoord2f(0.0f, 0.0f);glVertex3f(0.0f,6.0f,4.0f);
		glEnd();
		glEnable(GL_CULL_FACE);
	glEndList();

	glNewList(PORTE+TEXTURE,GL_COMPILE);
	Texture_on(LATTES);
		glCallList(PORTE);
		Texture_off();
	glEndList();
	
	glNewList(FENETRE,GL_COMPILE);
		glColor4f(0.0f,0.0f,0.60f,0.25f);
		glBegin(GL_QUADS);
			glNormal3f(1.0f,0.0f,0.0f);
			glVertex3f(0.0f,4.0f,0.0f);
			glVertex3f(0.0f,0.0f,0.0f);
			glVertex3f(0.0f,0.0f,4.0f);
			glVertex3f(0.0f,4.0f,4.0f);
		glEnd();
		glDisable(GL_CULL_FACE);
		glBegin(GL_QUADS);
			glNormal3f(-1.0f,0.0f,0.0f);
			glVertex3f(0.0f,4.0f,0.0f);
			glVertex3f(0.0f,0.0f,0.0f);
			glVertex3f(0.0f,0.0f,4.0f);
			glVertex3f(0.0f,4.0f,4.0f);
		glEnd();
		glEnable(GL_CULL_FACE);
	glEndList();

	glNewList(MUR_1,GL_COMPILE);
		glBegin(GL_QUADS);
			glNormal3f(-1.0f,0.0f,0.0f);
			glTexCoord2f(1.5f, 0.0f);glVertex3f(0.0f,8.0f,0.0f);
			glTexCoord2f(1.5f, 3.0f);glVertex3f(0.0f,0.0f,0.0f);
			glTexCoord2f(0.0f, 3.0f);glVertex3f(0.0f,0.0f,3.0f);
			glTexCoord2f(0.0f, 0.0f);glVertex3f(0.0f,8.0f,3.0f);
		glEnd();
		glDisable(GL_CULL_FACE);
		glBegin(GL_QUADS);
			glNormal3f(1.0f,0.0f,0.0f);
			glTexCoord2f(1.5f, 0.0f);glVertex3f(0.0f,8.0f,0.0f);
			glTexCoord2f(1.5f, 3.0f);glVertex3f(0.0f,0.0f,0.0f);
			glTexCoord2f(0.0f, 3.0f);glVertex3f(0.0f,0.0f,3.0f);
			glTexCoord2f(0.0f, 0.0f);glVertex3f(0.0f,8.0f,3.0f);
		glEnd();
		glEnable(GL_CULL_FACE);
	glEndList();

	glNewList(MUR_2,GL_COMPILE);
		glBegin(GL_QUADS);
			glNormal3f(-1.0f,0.0f,0.0f);
			glTexCoord2f(2.0f, 0.0f);glVertex3f(0.0f,2.0f,0.0f);
			glTexCoord2f(2.0f, 1.0f);glVertex3f(0.0f,0.0f,0.0f);
			glTexCoord2f(0.0f, 1.0f);glVertex3f(0.0f,0.0f,4.0f);
			glTexCoord2f(0.0f, 0.0f);glVertex3f(0.0f,2.0f,4.0f);
		glEnd();
		glDisable(GL_CULL_FACE);
		glBegin(GL_QUADS);
			glNormal3f(1.0f,0.0f,0.0f);
			glTexCoord2f(2.0f, 0.0f);glVertex3f(0.0f,2.0f,0.0f);
			glTexCoord2f(2.0f, 1.0f);glVertex3f(0.0f,0.0f,0.0f);
			glTexCoord2f(0.0f, 1.0f);glVertex3f(0.0f,0.0f,4.0f);
			glTexCoord2f(0.0f, 0.0f);glVertex3f(0.0f,2.0f,4.0f);
		glEnd();
		glEnable(GL_CULL_FACE);
	glEndList();

	glNewList(MURS,GL_COMPILE);
		glPushMatrix();
			glCallList(MUR);
			glTranslatef(10.0f,0.0f,0.0f);
			glCallList(MUR);
			glRotatef(90,0.0f,1.0f,0.0f);
			glTranslatef(0.0f,0.0f,-10.0f);
			glCallList(MUR_1);
			glTranslatef(0.0f,0.0f,7.0f);
			glCallList(MUR_1);
			glTranslatef(0.0f,6.0f,-4.0f);
			glCallList(MUR_2);

			glTranslatef(-20.0f,-6.0f,-3.0f);
			glCallList(MUR_1);
			glTranslatef(0.0f,0.0f,7.0f);
			glCallList(MUR_1);
			glTranslatef(0.0f,0.0f,-4.0f);
			glCallList(MUR_2);
			glTranslatef(0.0f,6.0f,0.0f);
			glCallList(MUR_2);
		glPopMatrix();
	glEndList();

	glNewList(MURS+TEXTURE,GL_COMPILE);
		Texture_on(PIERRES);
		glCallList(MURS);
		Texture_off();
	glEndList();

	glNewList(TOIT+TEXTURE,GL_COMPILE);
		Texture_on(LATTES);
		glCallList(TOIT);
		Texture_off();
	glEndList();
	
	glNewList(PLANCHE+TEXTURE,GL_COMPILE);
		Texture_on(LATTES);
		glBegin(GL_QUADS);
			glNormal3f(0.0f,1.0f,0.0f);
			glTexCoord2f(1.0f, 0.0f);glVertex3f(0.0f,0.1f,20.0f);
			glTexCoord2f(1.0f, 1.0f);glVertex3f(10.0f,0.1f,20.0f);
			glTexCoord2f(0.0f, 1.0f);glVertex3f(10.0f,0.1f,0.0f);
			glTexCoord2f(0.0f, 0.0f);glVertex3f(0.0f,0.1f,0.0f);
		glEnd();
		Texture_off();
	glEndList();

	glNewList(MAISON,GL_COMPILE);
		glPushMatrix();
			glCallList(MURS);
			glTranslatef(7.0f,0.0f,-4.0f);
			glCallList(PORTE);
			glTranslatef(-7.0f,0.0f,4.0f);
			glTranslatef(5.0f,7.5f,21.0f);
			glRotatef(90.0f,0.0f,1.0f,0.0f);
			glScalef(11.0f,4.0f,6.0f);
			glCallList(TOIT);
			glCullFace(GL_FRONT);
			glCallList(TOIT);
			glCullFace(GL_BACK);
		glPopMatrix();
	glEndList();

	glNewList(MAISON+TEXTURE,GL_COMPILE);
		glPushMatrix();
			glCallList(PLANCHE+TEXTURE);
			glCallList(MURS+TEXTURE);
			glTranslatef(7.0f,0.0f,-4.0f);
			glCallList(PORTE+TEXTURE);
			glTranslatef(-7.0f,0.0f,4.0f);
			glTranslatef(5.0f,7.5f,21.0f);
			glRotatef(90.0f,0.0f,1.0f,0.0f);
			glScalef(11.0f,4.0f,6.0f);
			glCallList(TOIT+TEXTURE);
			glCullFace(GL_FRONT);
			glRGB(50,50,50);
			glCallList(TOIT);
			glCullFace(GL_BACK);
		glPopMatrix();
		glPushMatrix();
			glTranslatef(3.0f,2.0f,20.0f);
			glRotatef(90.0f,0.0f,1.0f,0.0f);
			Transparence_on();
			glCallList(FENETRE);
			Transparence_off();
		glPopMatrix();
	glEndList();

	glNewList(FLAQUE,GL_COMPILE);
		glPushMatrix();
			glRotatef(90.0f,1.0f,0.0f,0.0f);
			Cercle(7.0f,2*PI,9);
		glPopMatrix();
	glEndList();

	glNewList(FLAQUE+TEXTURE,GL_COMPILE);
		Texture_on(EAU);
		glCallList(FLAQUE);
		Texture_off();
	glEndList();

	glNewList(MARGELLE_EXT,GL_COMPILE);
		glPushMatrix();
			glTranslatef(0.0f,1.0f,0.0f);
			Cylindre(1.0f,8.0f,6,1);
		glPopMatrix();
	glEndList();

	glNewList(MARGELLE_INT,GL_COMPILE);
		glPushMatrix();
			glTranslatef(0.0f,1.0f,0.0f);
			Cylindre(1.0f,7.5f,6,0);
		glPopMatrix();
	glEndList();

	glNewList(MARGELLE_EXT+TEXTURE,GL_COMPILE);
		glRGB(128,128,128);
		glCallList(MARGELLE_EXT);
	glEndList();

	glNewList(MARGELLE_INT+TEXTURE,GL_COMPILE);
		glRGB(128,128,128);
		glCallList(MARGELLE_INT);
	glEndList();

	glNewList(MARGELLE_SUP,GL_COMPILE);
	{
		GLfloat angle,fStep = (float)PI/6.0f;

		glFrontFace(GL_CW);
		glBegin(GL_QUAD_STRIP);
			glNormal3f(0,1,0);
			
			glVertex3f(0.0f, 1.0f, 7.5f);
			glVertex3f(0.0f, 1.0f, 8.0f);
			for(angle = fStep; angle <2.0f*PI; angle += fStep)
			{
				glVertex3f(8.0f*fsin(angle), 2.0f, 8.0f*fcos(angle));
				glVertex3f(7.5f*fsin(angle), 2.0f, 7.5f*fcos(angle));				
			}
		glEnd();
		glFrontFace(GL_CCW);
	}
	glEndList();

	glNewList(MARGELLE_SUP+TEXTURE,GL_COMPILE);
		glRGB(128,128,128);
		glCallList(MARGELLE_SUP);
	glEndList();

	glNewList(MARE,GL_COMPILE);
		glPushMatrix();
			glCallList(MARGELLE_EXT);
			glCallList(MARGELLE_INT);
			glCallList(MARGELLE_SUP);
			glTranslatef(0.0f,1.0f,0.0f);
			glCallList(FLAQUE);
		glPopMatrix();
	glEndList();

	glNewList(MARE+TEXTURE,GL_COMPILE);
		glPushMatrix();
			glCallList(MARGELLE_EXT+TEXTURE);
			glCallList(MARGELLE_INT+TEXTURE);
			glCallList(MARGELLE_SUP+TEXTURE);
			glTranslatef(0.0f,1.0f,0.0f);
			glCallList(FLAQUE+TEXTURE);
		glPopMatrix();
	glEndList();
}

void Draw_Scene(int texture)
{
	glPushMatrix();
		glPushMatrix();
			glTranslatef(25.0f,0.0f,60.0f);
			glCallList(ARBRE+texture);
			glTranslatef(-50.0f,0.0f,0.0f);
			glCallList(ARBRE+texture);
		glPopMatrix();
		glPushMatrix();
			glTranslatef(25.0f,0.0f,-60.0f);
			glCallList(ARBRE+texture);
			glTranslatef(-50.0f,0.0f,0.0f);
			glCallList(ARBRE+texture);
		glPopMatrix();
		glPushMatrix();
			glTranslatef(-75.0f,0.0f,-10.0f);
			glCallList(ARBRE+texture);
			glTranslatef(150.0f,0.0f,0.0f);
			glCallList(ARBRE+texture);
		glPopMatrix();
		glPushMatrix();
			glCallList(TEMPLE+texture);
			glTranslatef(-5.0f,0.0f,46.0f);
			glCallList(ESCALIER+texture);
			glTranslatef(-3.0f,0.0f,2.0f);
			glCallList(CHEMIN+texture);
			glTranslatef(-50.0f,0.0f,-25.0f);
			glRotatef(90.0,0.0f,1.0f,0.0f);
			glCallList(MAISON+texture);
			glTranslatef(5.0f,0.0f,110.0f);
			glCallList(MARE+texture);
		glPopMatrix();	
	glPopMatrix();
}

void Ombres(int val_stencil)
{
	Make_Ombres(SOL_UNIFORME,val_stencil,points_sol,light0_pos);
}

void Init_Collisions()
{
	float w, r, i, j;  //ne peut pas servir d'indice !!!
	//***************** temple *********************
	// base du temple
	for(w=-40;w<40;w++) for(r=-20;r<20;r++) Set_High(r,w,4.0f);
	// piliers
	for(w=-15;w<=15;w+=30) for(r=-35;r<=35;r+=35) 
		for (i=w-4;i<=w+4;i++) for (j=r-4;j<=r+4;j++) Set_High(i,j,20.0f);
	//escalier
	 for(w=-5;w<=5;w++)
	 {
			Set_High(w,46,1.0f);
			Set_High(w,45,1.5f);
			Set_High(w,44,2.0f);
			Set_High(w,43,2.5f);
			Set_High(w,42,3.0f);
			Set_High(w,41,3.5f);
			Set_High(w,40,4.0f);
	 }
	 //maison
	 for(w=-58;w<=-38;w++) Set_High(w,12,8.0f);
	 for(w=-58;w<=-38;w++) Set_High(w,22,8.0f);
	 for(w=12;w<=22;w++) Set_High(-38,w,8.0f);
	 for(w=12;w<=15;w++) Set_High(-58,w,8.0f);
	 for(w=19;w<=22;w++) Set_High(-58,w,8.0f);
	 //porte
	 for(w=-58;w>=-62;w--) Set_High(w,15,8.0f);
}

void load_Textures()
{
	printf("Chargement des textures :\n");
	printf("\ttexture herbe0.tga : %d\n",loadTGA("./textures/herbe0.tga",HERBE,0));
	printf("\ttexture herbe1.tga : %d\n",loadTGA("./textures/herbe1.tga",HERBE,1));
	printf("\ttexture herbe2.tga : %d\n",loadTGA("./textures/herbe2.tga",HERBE,2));
	printf("\ttexture herbe3.tga : %d\n",loadTGA("./textures/herbe3.tga",HERBE,3));
	printf("\ttexture ciel.tga : %d\n",loadTGA("./textures/ciel.tga",CIEL_T,0));
	printf("\ttexture caillou.tga : %d\n",loadTGA("./textures/caillou.tga",CAILLOU,0));
	printf("\ttexture pierres.tga : %d\n",loadTGA("./textures/pierres.tga",PIERRES,0));
	printf("\ttexture lattes.tga : %d\n",loadTGA("./textures/lattes.tga",LATTES,0));
	printf("\ttexture marbre0.tga : %d\n",loadTGA("./textures/marbre0.tga",MARBRE,0));
	printf("\ttexture marbre1.tga : %d\n",loadTGA("./textures/marbre1.tga",MARBRE,1));
	printf("\ttexture marbre2.tga : %d\n",loadTGA("./textures/marbre2.tga",MARBRE,2));
	printf("\ttexture marbre3.tga : %d\n",loadTGA("./textures/marbre3.tga",MARBRE,3));
	printf("\ttexture water.tga : %d\n",loadTGA("./textures/water.tga",EAU,0));
}