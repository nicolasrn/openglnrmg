GLfloat light0_pos[4];
GLfloat obj_x, obj_y, obj_z;
GLfloat collision[200][200];
GLfloat couleur_brouillard[4];
GLfloat ambient[4];
GLfloat diffuse[4];
GLfloat specular[4];
int animation_camera[2][MAX_ANIM_CAMERA];

void Init_World();
void Draw_World();
void Brouillard_on();
void Brouillard_off();
void Set_Lights(GLfloat ambient[4],GLfloat diffuse[4],GLfloat specular[4]);
void Set_Brouillard_Color();
