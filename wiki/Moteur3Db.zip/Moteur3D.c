/*									TPFH R�alit� virtuelle								*
 *											(ESIEA)										*
 ****************************************************************************************/
/* Juste un petit mot : 
		J'ai essay� de faire une programme le plus g�n�ral possible, c.a.d permettant 
		de cr�er le plus de sc�nes possibles. Mais je n'ai cr�� qu'une seule sc�ne avec.
		Je sais que certaines chose pourait �tre am�lior�, � savoir : un syst�me de
		chargement de fichiers externes pour les objets (objets 3DSMax), et syst�me de 
		chargement des animations, l� encore, dans un fichier s�par�. Enfin, il faudrait 
		que je reprenne totalement le programme pour mieux le structurer et ainsi �viter 
		les probl�mes d'appel � des variables externes, et les probl�mes de port�e des 
		variables (peut_�tre passage en C++ ?).Tout ceci fera partie de la prochaine version...
		D'ici l�, j'attend tous vos conseils en la mati�re.

	Olivier LANNELUC
	ESIEA
	oliv5@caramail.com
*/
		
#include <windows.h>					// En-t�te standart aux prog. Windows
#include <gl\gl.h>						// fonctions OpenGL
#include <gl\glaux.h>					// Librairie AUX
#include <math.h>
#include <stdio.h>
#include "definitions.h"
#include "effets.h"

//variables internes pour l'affichage
GLfloat clipHeight;
GLfloat clipWidth;
GLfloat angle_of_view;
//***********************************
GLfloat regard=ANGLE_REGARD;											//angle de vue par rapport � l'axe des Z
GLfloat eye_x, eye_y, eye_z, vue_x, vue_y, vue_z;						//variables de position et vecteur vue
int ombre_on=1, sol_uniforme=0, is_there_collisions=1, 
    is_mirroir_on=0, is_brouillard=0, animation_on=0, type_animation=4; //les noms parlent d'eux m�me
GLfloat longueur=0.0f;
int anim_pos=0;

void Move_Viewer(int dStep, int cStep);
void Change_Animation();

//vide le tableau des collisions
void Init_tab_collisions()
{
	int w,r;

	for(w=0;w<200;w++)
		for(r=0;r<200;r++)
			collision[w][r]=0;
}

//intialise toute la sc�ne
// (� n'appeler qu'un seule fois, au d�but du programme)
void setup()
{
	Init_tab_collisions();
	glShadeModel(GL_SMOOTH);
	glFrontFace(GL_CCW);
	glCullFace(GL_BACK);
	glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);
	glClearStencil(6);
	Init_World();
	angle_of_view = 60;
}

//calcul du vecteur vision qui varie en cas de rotation de la cam�ra
void upDate_vision()
{
	float fRadius = 10.0f;

	vue_x = eye_x + fRadius*fcos(regard);
	vue_z = eye_z - fRadius*fsin(regard);
}

//boucle principale du programme
void CALLBACK Main_part(void)
{
	glPushMatrix();
	upDate_vision();
	gluLookAt(eye_x,eye_y+fcos(longueur),eye_z,vue_x,vue_y+fcos(longueur),vue_z,0.0f,1.0f,0.0f);
	if (is_brouillard) glClearColor(couleur_brouillard[0],couleur_brouillard[1],couleur_brouillard[2],couleur_brouillard[3]); 
	else glClearColor(0.0f, 0.0f, 0.0f, 1.0f );
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
	Draw_World();
	glFlush();
	auxSwapBuffers();
	glPopMatrix();
}

//****************************************
//Gestion des touches de d�placement
void CALLBACK Key_left(void)
{
	regard+= PI/30.0f;
}

void CALLBACK Key_right(void)
{
	regard-=PI/30.0f;
}

void CALLBACK Key_down(void)
{
	Move_Viewer(-ONE_MOVE,0);
}

void CALLBACK Key_up(void)
{
	Move_Viewer(ONE_MOVE,0);
}

void CALLBACK Key_a(void)
{
	Move_Viewer(0,-ONE_MOVE);
}

void CALLBACK Key_z(void)
{
	Move_Viewer(0,ONE_MOVE);
}

void CALLBACK Key_q(void)
{
	Move_Viewer(0,-ONE_MOVE);
	regard-= PI/30.0f;
}

void CALLBACK Key_s(void)
{
	Move_Viewer(0,ONE_MOVE);
	regard+= PI/30.0f;
}


//Fonctions sp�ciales (brouillard, miroir, ombres ...
void CALLBACK Key_g(void)
{
	ombre_on=1-ombre_on;
	printf("Ombre active ? : %d\n",ombre_on);
}

void CALLBACK Key_h(void)
{
	sol_uniforme=1-sol_uniforme;
	printf("Sol_uniforme ? : %d\n",sol_uniforme);
}

void CALLBACK Key_f(void)
{
	is_there_collisions=1-is_there_collisions;
	printf("Collision activees? : %d\n",is_there_collisions);
}

void CALLBACK Key_j(void)
{
	is_mirroir_on=1-is_mirroir_on;
	printf("Miroir active ? : %d\n",is_mirroir_on);
}

void CALLBACK Key_k(void)
{
	is_brouillard=1-is_brouillard;
	ombre_on=1-ombre_on;
	if (is_brouillard) Brouillard_on(); else Brouillard_off();	
	printf("Brouillard active ? : %d\tOmbre active ? : %d\n",is_brouillard,ombre_on);
}

//D�placement de la lumi�re
void CALLBACK Key_8(void)
{
	light0_pos[0]+=2;
}
void CALLBACK Key_2(void)
{
	light0_pos[0]-=2;
}
void CALLBACK Key_4(void)
{
	light0_pos[2]-=2;
}
void CALLBACK Key_6(void)
{
	light0_pos[2]+=2;
}
void CALLBACK Key_9(void)
{
	light0_pos[1]+=2;
}
void CALLBACK Key_3(void)
{
	light0_pos[1]-=2;
}

//Variation de l'intensit� de la lumi�re
void CALLBACK Key_7(void)
{
	ambient[0]+=0.1f;
	ambient[1]+=0.1f;
	ambient[2]+=0.1f;
	couleur_brouillard[0]+=0.1f;
	couleur_brouillard[1]+=0.1f;
	couleur_brouillard[2]+=0.1f;
	if (is_brouillard) Set_Brouillard_Color();
	Set_Lights(ambient, diffuse, specular);
}

void CALLBACK Key_1(void)
{
	ambient[0]-=0.1f;
	ambient[1]-=0.1f;
	ambient[2]-=0.1f;
	couleur_brouillard[0]-=0.1f;
	couleur_brouillard[1]-=0.1f;
	couleur_brouillard[2]-=0.1f;
	if (is_brouillard) Set_Brouillard_Color();
	Set_Lights(ambient, diffuse, specular);
}

//Lancement/Arret de l'animation
void CALLBACK Key_SPACE(void)
{
	animation_on=1-animation_on;
	if (animation_on) Change_Animation();
}

// remise � ZERO (position de la cam�ra, reset des animations ...)
void CALLBACK Key_ENTER(void)
{
	anim_pos=0;
	regard= START_REGARD;
	eye_x = STARTX;
	eye_y = Y_CAMERA;
	vue_y = Y_CAMERA;
	eye_z = STARTZ;
	Main_part();
}
//********************************************
//Gestion de l'animation
void Change_Animation()
{
	if (type_animation>=MAX_ANIM_CAMERA_TYPE) type_animation=0;else type_animation++;
	printf("\tChangement d'animation : %d\n",type_animation);
	switch (type_animation)
	{
	case 0 :
		ambient[0]=0.4f;
		ambient[1]=0.4f;
		ambient[2]=0.4f;
		Brouillard_off();
		is_brouillard=0;
		ombre_on=1;
		break;
	case 1 :
		ambient[0]=0.2f;
		ambient[1]=0.2f;
		ambient[2]=0.2f;
		Brouillard_off();
		is_brouillard=0;
		ombre_on=1;
		break;
	case 2 :
		ambient[0]=0.2f;
		ambient[1]=0.2f;
		ambient[2]=0.2f;
		couleur_brouillard[0]=0.2f;
		couleur_brouillard[1]=0.2f;
		couleur_brouillard[2]=0.2f;
		Set_Brouillard_Color();
		Brouillard_on();
		ombre_on=0;
		is_brouillard=1;
		break;
	case 3 : 
		ambient[0]=0.4f;
		ambient[1]=0.4f;
		ambient[2]=0.4f;
		couleur_brouillard[0]=0.4f;
		couleur_brouillard[1]=0.4f;
		couleur_brouillard[2]=0.4f;
		Set_Brouillard_Color();
		Brouillard_on();
		ombre_on=0;
		is_brouillard=1;
		break;
	}
	Set_Lights(ambient, diffuse, specular);
	anim_pos=0;
	Key_ENTER();
}

void CALLBACK Animation(void)
{
	if (animation_on)
	{
		if (anim_pos>=MAX_ANIM_CAMERA) Change_Animation();
		switch (animation_camera[0][anim_pos])
		{
			case AVANT : 
				Move_Viewer(animation_camera[1][anim_pos],0);
				break;
			case ARRIERE : 
				Move_Viewer(-animation_camera[1][anim_pos],0);
				break;
			case STRAFE_GAUCHE_ROTATION :
				Move_Viewer(0,-animation_camera[1][anim_pos]);
				regard-=PI/animation_camera[1][anim_pos];
			case STRAFE_DROIT_ROTATION :
				Move_Viewer(0,animation_camera[1][anim_pos]);
				regard+=PI/animation_camera[1][anim_pos];
			case DROITE : 
				regard-=PI/animation_camera[1][anim_pos];
				break;
			case GAUCHE : 
				regard+=PI/animation_camera[1][anim_pos];
				break;
			case STRAFE_GAUCHE : 
				Move_Viewer(0,-animation_camera[1][anim_pos]);
				break;
			case STRAFE_DROIT : 
				Move_Viewer(0,animation_camera[1][anim_pos]);
				break;
			case VIDE : break;
			default : printf("Fin de l'animation !!!\n");
		}
		anim_pos++;
		//printf("%d %d\n",anim_pos,animation_camera[0][anim_pos]);
		Main_part();
	}
}
//******************************************************
//Fonction g�rant l'agrandissement de la fen�tre
//(elle est lanc� une fois au d�but du programme par l'OpenGL)
void CALLBACK Reshape(GLsizei w, GLsizei h) //changement de taille de la fenetre ...
{
	GLfloat aspect;

	if (h == 0) h = 1;
	glViewport(0,0,w,h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	
	switch (PERSPECTIVE_ON)
	{
		case 0 : if (w<=h)
					{
						clipWidth  = (GLfloat)LARGEUR * h/w;
						clipHeight = (GLfloat)HAUTEUR;
					}
					else 
					{
						clipWidth = (GLfloat)LARGEUR;
						clipHeight = (GLfloat)HAUTEUR * w/h;
					}
					glOrtho( -clipWidth/2, clipWidth/2, -clipHeight/2, clipHeight/2, ZMIN, ZMAX);
				break;
		case 1 : aspect = (GLfloat) w / (GLfloat) h;
				 gluPerspective(angle_of_view, aspect, ZMIN, ZMAX);
				 break;
	}
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

//Gestion des collisions
int Test_Collision(GLfloat x, GLfloat y, GLfloat z, GLfloat* hauteur)
{
	(*hauteur) = collision[Make_Indice(x)][Make_Indice(z)];
	if (((*hauteur)-y)>MAX_HIGH) return 1;
	return 0;
}

int Collision(GLfloat* x, GLfloat y, GLfloat* z, GLfloat* hauteur, int dStep, int cStep, GLfloat xDelta, GLfloat zDelta)
{
	GLfloat pasX, pasZ, xStart, zStart;
	
	xStart=*x;
	zStart=*z;
	if (dStep==0) dStep=1;
	if (cStep==0) cStep=1;
	pasX=xDelta/abs(dStep)/abs(cStep);
	pasZ=zDelta/abs(dStep)/abs(cStep);
	if ((*x<xStart+xDelta) && (*z<zStart+zDelta))
	{
		while((*x<xStart+xDelta) && (*z<zStart+zDelta))
		{
			if (Test_Collision(*x,y,*z,hauteur)) 
			{
				*x-=3*pasX;
				*z-=3*pasZ;
				return 1;
			}
			*x+=pasX;
			*z+=pasZ;
		}
	}
	else if ((*x<xStart+xDelta) && (*z>zStart+zDelta)) 
	{
		*x=xStart;
		*z=zStart;
		while((*x<xStart+xDelta) && (*z>zStart+zDelta))
		{
			if (Test_Collision(*x,y,*z,hauteur)) 
			{
				*x-=3*pasX;
				*z-=3*pasZ;
				return 1;
			}
			*x+=pasX;
			*z+=pasZ;
		}
	}
	else if ((*x>xStart+xDelta) && (*z<zStart+zDelta))
	{
		*x=xStart;
		*z=zStart;
		while((*x>xStart+xDelta) && (*z<zStart+zDelta))
		{
			if (Test_Collision(*x,y,*z,hauteur)) 
			{
				*x-=3*pasX;
				*z-=3*pasZ;
				return 1;
			}
			*x+=pasX;
			*z+=pasZ;
		}
	}
	else if ((*x>xStart+xDelta) && (*z>zStart+zDelta))
	{
		*x=xStart;
		*z=zStart;
		while((*x>xStart+xDelta) && (*z>zStart+zDelta))
		{
			if (Test_Collision(*x,y,*z,hauteur)) 
			{
				*x-=3*pasX;
				*z-=3*pasZ;
				return 1;
			}
			*x+=pasX;
			*z+=pasZ;
		}
	}
	else if (*x<xStart+xDelta)
	{
		*x=xStart;
		while(*x<xStart+xDelta)
		{
			if (Test_Collision(*x,y,*z,hauteur)) 
			{
				*x-=3*pasX;
				return 1;
			}
			*x+=pasX;
		}
	}
	else if (*x>xStart+xDelta) 
	{
		*x=xStart;
		while(*x>xStart+xDelta)
		{
			if (Test_Collision(*x,y,*z,hauteur)) 
			{
				*x-=3*pasX;
				return 1;
			}
			*x+=pasX;
		}
	}
	else if (*z<zStart+zDelta)
	{
		*z=zStart;
		while(*z<zStart+zDelta)
		{
			if (Test_Collision(*x,y,*z,hauteur)) 
			{
				*z-=3*pasZ;
				return 1;
			}
			*z+=pasZ;
		}
	}
	else if (*z>zStart+zDelta)
	{
		*z=zStart;
		while(*z>zStart+zDelta)
		{
			if (Test_Collision(*x,y,*z,hauteur)) 
			{
				*z-=3*pasZ;
				return 1;
			}
			*z+=pasZ;
		}
	}
	return 0;
}

//Gestion du d�placement de la cam�ra
void Move_Viewer(int dStep, int cStep)
{
	GLfloat xDelta,zDelta;
	GLfloat hauteur=0.0f;

	xDelta = dStep*fcos(regard) - cStep*fcos(regard + PI/2.0f);
	zDelta = -dStep*fsin(regard) + cStep*fsin(regard + PI /2.0f);

	if (is_there_collisions)
	{
		if (!Collision(&eye_x, eye_y-Y_CAMERA, &eye_z, &hauteur,dStep,cStep,xDelta,zDelta))
		{
			eye_y = hauteur+Y_CAMERA;
			vue_y=eye_y;
		}
		else printf("Collision !!! : hauteur de la camera : %d\n",eye_y-5.0);
	}
	else
	{
		eye_x += xDelta;
		eye_z += zDelta;
	}

	if (eye_x > X_LIMITE) eye_x = X_LIMITE;
	if (eye_x < -X_LIMITE) eye_x = -X_LIMITE;
	if (eye_z > Z_LIMITE) eye_z = Z_LIMITE;
	if (eye_z < -Z_LIMITE) eye_z = -Z_LIMITE;
	
	longueur+=0.50f;
	if (longueur>70) longueur=-70;
}

//Quelques informations et remerciements
void info()
{
	printf("Moteur 3D v1.0\nOlivier LANNELUC\nESIEA 2eme annee\nTPFH Realite virtuelle\n\n");
	printf("Remerciements a: \n\tF. Gasser et J-F. Herouard (EFREI) \n\tCaedes (Forum PCteam)\n\n");
	printf("-------------------------------------------------------\n");
}

//initialisation de la fen�tre, de l'affichage, des touches ...
void main(void)
{
	auxInitDisplayMode(AUX_DOUBLE | AUX_RGBA | AUX_DEPTH | AUX_STENCIL);
	auxInitPosition(100,100,LARGEUR,HAUTEUR);
	auxInitWindow("Moteur 3D");
	info();
	setup();
	auxReshapeFunc(Reshape);
	auxKeyFunc(AUX_UP,Key_up);
	auxKeyFunc(AUX_DOWN,Key_down);
	auxKeyFunc(AUX_LEFT,Key_left);
	auxKeyFunc(AUX_RIGHT,Key_right);
	auxKeyFunc(AUX_a,Key_a);
	auxKeyFunc(AUX_z,Key_z);
	auxKeyFunc(AUX_q,Key_q);
	auxKeyFunc(AUX_s,Key_s);
	auxKeyFunc(AUX_g,Key_g);
	auxKeyFunc(AUX_h,Key_h);
	auxKeyFunc(AUX_f,Key_f);
	auxKeyFunc(AUX_j,Key_j);
	auxKeyFunc(AUX_k,Key_k);
	auxKeyFunc(AUX_7,Key_7);
	auxKeyFunc(AUX_1,Key_1);
	auxKeyFunc(AUX_2,Key_2);
	auxKeyFunc(AUX_8,Key_8);
	auxKeyFunc(AUX_4,Key_4);
	auxKeyFunc(AUX_6,Key_6);
	auxKeyFunc(AUX_9,Key_9);
	auxKeyFunc(AUX_3,Key_3);
	auxKeyFunc(AUX_SPACE,Key_SPACE);
	auxKeyFunc(AUX_RETURN,Key_ENTER);
	auxIdleFunc(Animation);
	auxMainLoop(Main_part);
}