#include <windows.h>	// Normal Windows stuff
#include <gl/gl.h>		// Core OpenGL functions
#include <gl/glu.h>		// OpenGL Utility functions
#include <gl/glaux.h>
#include <math.h>
#include <stdio.h>
#include "tga.h"
#include "definitions.h"
#include "world.h"

extern int follow_player, ombre_on, sol_uniforme, is_there_collisions, is_mirroir_on, is_brouillard;
extern GLfloat eye_x, eye_y, eye_z, vue_x, vue_y, vue_z, regard;

GLfloat Matrice_Ombre[4][4];

//Fonctions calculant la normale � une surface
//Transformation en vecteur unit�
void Vecteur_Unite(float vector[3])
{
	float length;
	
	// Calcul de la norme		
	length = (float)sqrt((vector[0]*vector[0]) + 
						(vector[1]*vector[1]) +
						(vector[2]*vector[2]));
	// on �vite une grosse erreur !!!
	if(length == 0.0f)
		length = 1.0f;

	//on divise le vecteur par sa norme : il est alors unitaire
	vector[0] /= length;
	vector[1] /= length;
	vector[2] /= length;
}


// Les 3 points sont � entrer dans le sens trigonom�trique
void Normale(float v[3][3], float out[3])
{
	float v1[3],v2[3];
	static const int x = 0;
	static const int y = 1;
	static const int z = 2;

	// Calcul de 2 vecteurs � partir des 3 points
	v1[x] = v[0][x] - v[1][x];
	v1[y] = v[0][y] - v[1][y];
	v1[z] = v[0][z] - v[1][z];

	v2[x] = v[1][x] - v[2][x];
	v2[y] = v[1][y] - v[2][y];
	v2[z] = v[1][z] - v[2][z];

	// Produit vectoriel
	out[x] = (v1[y]*v2[z] - v1[z]*v2[y]);
	out[y] = (v1[z]*v2[x] - v1[x]*v2[z]);
	out[z] = (v1[x]*v2[y] - v1[y]*v2[x]);

	// Il faut un vecteur unit�
	Vecteur_Unite(out);
}

//Calcul de la matrice de projection permettant de dessiner les ombres
//On ne peut dessiner ces ombres QUE sur le sol, 
//ou sur une surface derri�re laquelle ne doit se trouver aucun objet
void MakeShadowMatrix(GLfloat points_plan[3][3], GLfloat lightPos[4], GLfloat destMat[4][4])
{
	GLfloat planeCoeff[4];
	GLfloat dot;

	//on calcule un vecteur normal � ce plan
	Normale(points_plan,planeCoeff);

	// le dernier coefficient se calcule par substitution
	planeCoeff[3] = - (
		(planeCoeff[0]*points_plan[2][0]) + (planeCoeff[1]*points_plan[2][1]) +
		(planeCoeff[2]*points_plan[2][2]));
	
	dot = planeCoeff[0] * lightPos[0] +
			planeCoeff[1] * lightPos[1] +
			planeCoeff[2] * lightPos[2] +
			planeCoeff[3] * lightPos[3];

	// Now do the projection
	// 1�re colonne
        destMat[0][0] = dot - lightPos[0] * planeCoeff[0];
        destMat[1][0] = 0.0f - lightPos[0] * planeCoeff[1];
        destMat[2][0] = 0.0f - lightPos[0] * planeCoeff[2];
        destMat[3][0] = 0.0f - lightPos[0] * planeCoeff[3];

	// 2�me colonne
	destMat[0][1] = 0.0f - lightPos[1] * planeCoeff[0];
	destMat[1][1] = dot - lightPos[1] * planeCoeff[1];
	destMat[2][1] = 0.0f - lightPos[1] * planeCoeff[2];
	destMat[3][1] = 0.0f - lightPos[1] * planeCoeff[3];

	// 3�me colonne
	destMat[0][2] = 0.0f - lightPos[2] * planeCoeff[0];
	destMat[1][2] = 0.0f - lightPos[2] * planeCoeff[1];
	destMat[2][2] = dot - lightPos[2] * planeCoeff[2];
	destMat[3][2] = 0.0f - lightPos[2] * planeCoeff[3];

	// 4�me colonne
	destMat[0][3] = 0.0f - lightPos[3] * planeCoeff[0];
	destMat[1][3] = 0.0f - lightPos[3] * planeCoeff[1];
	destMat[2][3] = 0.0f - lightPos[3] * planeCoeff[2];
	destMat[3][3] = dot - lightPos[3] * planeCoeff[3];
}

//Quelques fonctions utilitaires
void Addition(float t[3], float y[3], float res[3])
{
	res[0]=t[0]+y[0];
	res[1]=t[1]+y[1];
	res[2]=t[2]+y[2];
}

void Moyenne(float t[3], float y[3], float res[3])
{
	Addition(t,y,res);
	Vecteur_Unite(res);
}

//Initialisation des textures
//(on dessine tout en blanc, puis on place la texture)
//(la position de la lumi�re va influer sur l'�clairement de cette texture)
void Texture_on(int id)
{
	glEnable(GL_TEXTURE_2D);
	glRGB(255,255,255);
	glBindTexture(GL_TEXTURE_2D, id);
}

void Texture_off()
{
	glDisable(GL_TEXTURE_2D);
}

//Initialisation des param�tres d'�clairage : lumi�re et reflexion des objets
void Set_Obj_Reflexion(GLfloat specular_reflexion_obj[4], GLint shiny_obj)
{
	glEnable(GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);
	glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,specular_reflexion_obj);
	glMateriali(GL_FRONT_AND_BACK,GL_SHININESS,shiny_obj);
}

void Set_Obj_Reflexion4f(GLfloat a1, GLfloat a2, GLfloat a3, GLint shiny_obj)
{
	GLfloat specular_reflexion_obj[]={a1,a2,a3,1.0f};
	glEnable(GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);
	glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,specular_reflexion_obj);
	glMateriali(GL_FRONT_AND_BACK,GL_SHININESS,shiny_obj);
}

void Set_Lights(GLfloat ambient[4],GLfloat diffuse[4],GLfloat specular[4])
{
	glEnable(GL_LIGHTING);
	glLightfv(GL_LIGHT0,GL_AMBIENT,ambient);
	glLightfv(GL_LIGHT0,GL_DIFFUSE,diffuse);
	glLightfv(GL_LIGHT0,GL_SPECULAR,specular);
	glEnable(GL_LIGHT0);
}

void Set_Lights4f(GLfloat a1,GLfloat a2,GLfloat a3, GLfloat b1, GLfloat b2, GLfloat b3, GLfloat c1, GLfloat c2, GLfloat c3)
{
	GLfloat ambient[]={a1,a2,a3,1.0f};
	GLfloat diffuse[]={b1,b2,b3,1.0f};
	GLfloat specular[]={c1,c2,c3,1.0f};

	glEnable(GL_LIGHTING);
	glLightfv(GL_LIGHT0,GL_AMBIENT,ambient);
	glLightfv(GL_LIGHT0,GL_DIFFUSE,diffuse);
	glLightfv(GL_LIGHT0,GL_SPECULAR,specular);
	glEnable(GL_LIGHT0);
}

//Initialisation du monde environnent
//(est appel�e dans la fonction Setup du fichier Moteur.c)
void Init_World()
{
	load_Textures();
	Set_Lights(ambient, diffuse, specular);
	Set_Obj_Reflexion(specular_reflexion_obj, shiny_obj);
	Init_Obj();
	if (is_there_collisions) Init_Collisions();
	regard= START_REGARD;
	eye_x = STARTX;
	eye_y = Y_CAMERA;
	vue_y = Y_CAMERA;
	eye_z = STARTZ;
}

//Activation et initialisation du brouillard
void Set_Brouillard_Color()
{
	glFogfv(GL_FOG_COLOR, couleur_brouillard);
}

void Brouillard_on()
{
	glEnable(GL_FOG);
	glFogfv(GL_FOG_COLOR, couleur_brouillard);
	glFogi(GL_FOG_MODE, FOG_TYPE);
	glFogf(GL_FOG_START, FOG_START);
	glFogf(GL_FOG_END, FOG_END);
	glFogf(GL_FOG_DENSITY, FOG_DENSITE);
}

void Brouillard_off()
{
	glDisable(GL_FOG);
}

//Initialisation et arr�t de la transparence d'un objet
void Transparence_on()  //a appeler apres le dessin des objets que l'on verra par tranparence 
{
	glEnable(GL_BLEND);	
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

void Transparence_off()
{
	glDisable(GL_BLEND);
}

//Cr�ation des ombres
// Entr�es : 
//			* ID : identificateur de la surface sur laquelle sont dessinn�es les ombres
//			* val_stencil : valeur de r�f�rence dans le stencil Buffer sur laquelle on dessine les ombres
//			* surface : tableau contenant 3 point appartenant � la surface recevant les ombgres
//			* light_pos : tableau indiquant ... la position de la lumi�re
void Make_Ombres(int ID, int val_stencil, GLfloat surface[3][3], GLfloat light_pos[4])
{
	glDisable(GL_DEPTH_TEST);
	glStencilFunc(GL_EQUAL, val_stencil, 0xffffffff);	
	glStencilOp(GL_KEEP, GL_INCR, GL_INCR);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	MakeShadowMatrix(surface,light_pos,Matrice_Ombre);
	glPushMatrix();	
	  glColor4f(0.0f, 0.0f, 0.0f, 0.25f); 
	  glMultMatrixf((GLfloat *) Matrice_Ombre);	
	  Draw_Scene(SANS_COULEUR);
	glPopMatrix();
	glEnable(GL_DEPTH_TEST);
}

//Calcul du reflet dans une surface
// Entr�es :
//			* axe : axe par rapport auquel va s'effectuer la sym�trie (axeX = 1, axeY = 2, AxeZ = 3)
//			* val : valeur de la translation que l'on doit r�aliser selon l'axe "axe" avant de faire la sym�trie
//			* ID  : identificateur de la surface r�fl�chissante			
void Reflet(int axe,GLfloat val, int ID)
{
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_STENCIL_TEST);
	glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);	
	glStencilOp(GL_REPLACE, GL_REPLACE, GL_REPLACE);	
	glStencilFunc(GL_ALWAYS, 7, 0xffffffff);	
	glCallList(ID);										//desin de la surface refl�chisante dans le Stencil buffer
	glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);	//pour un futur d�coupage de la sc�ne refl�t�e
	glEnable(GL_DEPTH_TEST);
	glStencilFunc(GL_EQUAL, 7, 0xffffffff);
	glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);	
	glDisable(GL_CULL_FACE);
	glPushMatrix();
		switch (axe)
		{
		case 1 : 
			glTranslatef(val,0.0f,0.0f);
			glScalef(-1.0f, 1.0f,1.0f);
			break;
		case 2 : 
			glTranslatef(0.0f,val,0.0f);
			glScalef(1.0f, -1.0f,1.0f);
			break;
		case 3 : 
			glTranslatef(0.0f,0.0f,val);
			glScalef(1.0f, 1.0f,-1.0f);
			break;
		default : printf("Erreur de parametrage !!!");
		}
		glLightfv(GL_LIGHT0,GL_POSITION,light0_pos);
			
		// objets refletes	
		Draw_Scene(TEXTURE);
		glDisable(GL_CULL_FACE);
		if (!is_brouillard) glCallList(CIEL);
		glStencilOp(GL_KEEP, GL_KEEP, GL_INCR);	
		if (!sol_uniforme) glCallList(SOL); else glCallList(SOL_UNIFORME);
		if (ombre_on) Ombres(8);
		DrawLight0();
		// fin liste obj refletes
	glPopMatrix();
	glLightfv(GL_LIGHT0,GL_POSITION,light0_pos);
	glDisable(GL_STENCIL_TEST);
	// dessin du miroir un peu transparent
	glEnable(GL_BLEND);	
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glCallList(ID+TEXTURE);
	glDisable(GL_BLEND);
	
	glEnable(GL_CULL_FACE);
	glClear(GL_STENCIL_BUFFER_BIT);
}

//Dessin du monde environnent
//(effectue un appel � toutes les fonctions d'effet "sp�ciaux" : reflet, ombres ...)
void Draw_World()
{
	glLightfv(GL_LIGHT0,GL_POSITION,light0_pos);	
	if (is_mirroir_on) Reflet(3,202.0f,MIRROIR);
	if (!is_brouillard) glCallList(CIEL);
	glEnable(GL_STENCIL_TEST);							//on dessine le sol dans le Stencil-buffer pour le futur dessin des ombres 
	glStencilOp(GL_REPLACE, GL_REPLACE, GL_REPLACE);	//(permet de faire un d�coupage de la zone o� apparaissent les ombres)
	glStencilFunc(GL_ALWAYS, 1, 0xffffffff);
	if (!sol_uniforme) glCallList(SOL); else glCallList(SOL_UNIFORME);
	if (ombre_on) Ombres(1);
	glDisable(GL_STENCIL_TEST);
	Draw_Scene(TEXTURE);								//Fonctions g�rant le dessin et le positionnement des objets
	DrawLight0();
}
////////////////////////////////////////////////////////////////////////////////

