#define PI 3.14159265f
#define X_LIMITE 100.0f				//limites du terrain en X (moiti� du terrain,car on commence � l'origine)
#define Y_LIMITE 100.0f				//limites du terrain en Y (idem)
#define Z_LIMITE 100.0f				//limites du terrain en Z (idem)
#define X_LIMITE_DECOR 800.0f		//sert pour les limites du ciel
#define Z_LIMITE_DECOR 800.0f
#define glRGB(x, y, z) glColor3ub((GLubyte)x, (GLubyte)y, (GLubyte)z)					//pour �viter de taper sans cesse glColor3f(...);
#define glRGBA(x, y, z, a) glColor4ub((GLubyte)x, (GLubyte)y, (GLubyte)z, (GLuByte)a)	//idem avec la valeur alpha
#define fsin(x)	(float)sin(x)
#define fcos(x) (float)cos(x)
#define Make_Indice(x) (int)(x+100.0f)	//donne la case du tableau des collisions sorrespondant � la valeur x sur le terrain

#define CARREAU			20			//taille d'un carreau sur le sol (plus il est gros, moins il y en a a l'�cran, et plus c'est rapide...)
#define TEXTURE			200			//d�calage dans la positions des CallListes entre objets textures et non textur�s
#define SANS_COULEUR	0			//idem (juste pour la forme)
#define LARGEUR			500			//largeur et hauteur de la fen�tre
#define HAUTEUR			500
#define ZMIN			1			//valeur du z minimal des objets affich�s
#define ZMAX			2000		//valeur du z maximal des objets affich�s
#define PERSPECTIVE_ON	1
#define MAX_HIGH		3			//hauteur maximal que la cam�ra peut monter sans qu'il y ait collision
#define ONE_MOVE		5			//valeur d'un pas en avant, arri�re, strafe gauche/droit

#define STARTX			-85			//position de d�part
#define Y_CAMERA		5
#define STARTZ			0
#define ANGLE_REGARD	0
#define START_REGARD	0
#define FOG_TYPE		GL_LINEAR	//caract�ristique initiale du brouillard
#define FOG_DENSITE		0.020
#define FOG_START		20
#define FOG_END			80
#define MAX_ANIM_CAMERA	90			//nb d'�tapes dans l'animation
#define MAX_ANIM_CAMERA_TYPE	3	//nb total d'animation (on commence � 0 !!!)

typedef enum						//Identificateurs des objets cr��s
{
	CASE_VIDE,
	BASE_PILIER,
	PILIER,	
	SOL,			
	SOL_UNIFORME,
	AVION,	
	REMORQUE,
	ROUE,		
	PANCARTE,
	CORPS_PILIER,
	FEUILLE,	
	BRANCHE,		
	ARBRE,		
	CORPS_REMORQUE,
	TEMPLE,
	TOIT,			
	PAN_TOIT1,
	PAN_TOIT2,		
	MIRROIR_PILE,
	MIRROIR_CARRE,
	MIRROIR,	
	MIRROIR_FACE,
	MIRROIR_DEMI,	
	ESCALIER,	
	MARCHE,		
	MIRROIR_CARRE2,
	CIEL,
	CIEL_NUIT,
	MARE,			
	MARGELLE_EXT,
	FLAQUE,	
	MARGELLE_INT,
	MARGELLE_SUP,
	CHEMIN,	
	PETIT_MUR,
	MUR,		
	MURS,
	MUR_PORTE,
	MAISON,		
	PLANCHE,
	PORTE,
	MUR_1,			
	MUR_2,			
	FENETRE,
} Objets;

typedef enum				//Identificateur des textures une fois charg�e dans la m�moire vid�o
{
	HERBE,
	CIEL_T, 
	EAU, 
	PIERRES, 
	CAILLOU, 
	LATTES, 
	PHOTO,
	MARBRE,
} Textures;

typedef enum					//Diff�rents types de mouvements possibles
{
	VIDE,
	AVANT,
	ARRIERE,
	STRAFE_GAUCHE_ROTATION,
	STRAFE_DROIT_ROTATION,
	PLUSY,
	MOINSY,
	GAUCHE,
	DROITE,
	STRAFE_GAUCHE,
	STRAFE_DROIT,
} Animations;
