GLfloat light0_pos[4];
GLfloat ambient[4];
GLfloat diffuse[4];
GLfloat specular[4];
GLfloat specular_reflexion_obj[4];
GLfloat couleur_brouillard[4];
GLfloat collision[200][200];
GLubyte shiny_obj;
GLfloat obj_x, obj_y, obj_z;
int animation_camera[2][MAX_ANIM_CAMERA];

void Init_Obj();
void DrawLight0();
void Draw_Scene(int texture);
void load_Textures();
void Ombres();
void Init_Collisions();